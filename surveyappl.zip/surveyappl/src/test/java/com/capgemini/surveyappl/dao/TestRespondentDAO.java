package com.capgemini.surveyappl.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.RespondentInfoBean;
import com.capgemini.surveyappl.factory.FactoryClass;

/**
 * This test class of respondentdao side.
 * 
 * @author ELCOT
 *
 */
public class TestRespondentDAO {

	static final Logger log = Logger.getLogger(TestRespondentDAO.class);

	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Surveyid for responses")
	void testUserNameValidation() {
		RespondentDAO respondent = FactoryClass.getRespondentDAOInstance();
		assertNotNull(respondent.getResponseOfRespondent("1"));

	}

	@Test
	@DisplayName("Respondent Registration")
	void testRespondentRegValidation() {
		RespondentDAO respondentDao = FactoryClass.getRespondentDAOInstance();
		RespondentInfoBean bean = FactoryClass.getRespondentBeanInstance();

		bean.setrespondentId("respondent");
		bean.setrespondentFirstName("praba");
		bean.setrespondentLastName("karan");
		bean.setrespondentPassword("123");
		bean.setrespondentContact("9965749280");

		ArrayList<RespondentInfoBean> respondent = new ArrayList<>();
		respondent.add(bean);
		assertEquals(true, respondentDao.getRespondentRegistration(respondent));
	}

	@Test
	@DisplayName("Add the responses")
	void testRespondentAddValidation() {
		RespondentDAO respondentDao = FactoryClass.getRespondentDAOInstance();
		CreateRespondentDetailsBean bean = FactoryClass.getRespondentDetailsBean();

		bean.setquestionOneAnswerOne("qwerty");
		bean.setrespondentId("1");
		bean.setquestionId("1");
		ArrayList<CreateRespondentDetailsBean> respondent = new ArrayList<>();
		respondent.add(bean);
		assertEquals(true, respondentDao.getResponseAdd(respondent));
	}

	@Test
	@DisplayName("Valid Respondent Login")
	void testRespondentLoginValidation() {
		RespondentDAO respondentDao = FactoryClass.getRespondentDAOInstance();
		assertEquals(true, respondentDao.getRespondentLogin("respondent", "12345"));

	}

}
