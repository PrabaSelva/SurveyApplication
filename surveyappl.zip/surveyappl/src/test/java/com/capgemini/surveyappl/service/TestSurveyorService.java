package com.capgemini.surveyappl.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.SurveyorInfoBean;
import com.capgemini.surveyappl.factory.FactoryClass;

/**
 * This is test class of surveyor service
 * 
 * @author ELCOT
 *
 */

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TestSurveyorService {

	static final Logger log = Logger.getLogger(TestSurveyorService.class);

	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Valid userName")
	void testUserNameValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(true, service.userNameValidation("qwerty"));
	}

	@Test
	@DisplayName("InValid userName")
	void testUserNameValidation1() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(false, service.userNameValidation("qwerty%&"));
	}

	@Test
	@DisplayName("Valid surveyId")
	void testUseridValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(true, service.idValidation("1"));
	}

	@Test
	@DisplayName("InValid surveyId")
	void testUseridValidation1() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(false, service.idValidation("1a"));
	}

	@Test
	@DisplayName("Valid User Password")
	void testPasswordValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(true, service.passwordValidation("qwerty"));
	}

	@Test
	@DisplayName("InValid User Password")
	void testPasswordValidation1() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(false, service.passwordValidation("qwerty*^"));
	}

	@Test
	@DisplayName(" Valid ContactNumber")
	void testContactValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(true, service.contactNumberValidation("9965749280"));
	}

	@Test
	@DisplayName("InValid ContactNumber")
	void testContactValidation1() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(false, service.contactNumberValidation("99657492801"));
	}

	@Test
	@DisplayName("valid Start Date")
	void testStartDateValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(true, service.startDateValidation("1998-03-11"));
	}

	@Test
	@DisplayName("Invalid start date")
	void testStartDateValidation1() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(false, service.startDateValidation("1998q"));
	}

	@Test
	@DisplayName("Valid end date")
	void testEndDateValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(true, service.endDateValidation("1998-03-11"));
	}

	@Test
	@DisplayName("InValid end date")
	void testEndDateValidation1() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(false, service.endDateValidation("a"));
	}

	@Test
	@DisplayName("Valid choiceCheck")
	void testChoiceCheckValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(true, service.choiceCheckValidate("1"));
	}

	@Test
	@DisplayName("Invalid choiceCheck")
	void testChoiceCheckValidation1() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(false, service.choiceCheckValidate("1a"));
	}

	@BeforeAll
	@DisplayName("View  Survey")
	void testLoginSurveyValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertNotNull(service.viewSurvey("1"));
	}

	@Test
	@DisplayName("Delete Survey")
	void testDeleteSurveyValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(true, service.deleteSurvey("1"));
	}

	@Test
	@DisplayName("Add the Survey")
	void testAddSurveyValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		CreateSurveyDetailsBean bean = FactoryClass.getCreateSurveyDetails();
		bean.setid("4");
		bean.setname("java");
		bean.setAccessor("karan");
		bean.setdescription("java module");
		ArrayList<CreateSurveyDetailsBean> surveylist = new ArrayList<>();
		surveylist.add(bean);
		assertEquals(true, service.getSurveyorDaoAdd(surveylist));
	}

	@Test
	@DisplayName("register the survey")
	void testRegsSurveyValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		SurveyorInfoBean bean = FactoryClass.getSurveyorBeanInstance();
		bean.setfirstName("Praba");
		bean.setlastName("Karan");
		bean.setcontactNumber("9965749280");
		bean.setpassword("1234");
		bean.setuserId("1");
		ArrayList<SurveyorInfoBean> surveylist = new ArrayList<>();
		surveylist.add(bean);
		assertEquals(true, service.getSurveyorRegistration(surveylist));
	}

	@Test
	@DisplayName("Update the survey")
	void testUpdateSurveyValidation() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertNotNull(service.getUpdateSurvey("2"));

	}

	@Test
	@DisplayName("InValid CheckSurvey")
	void testCheckSurvey() {
		SurveyorService service = FactoryClass.getSurveyorServiceInstance();
		assertEquals(false, service.checkSurvey("1"));
	}
}
