package com.capgemini.surveyappl.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.RespondentInfoBean;
import com.capgemini.surveyappl.factory.FactoryClass;

/**
 * This is test class of respondent service side.
 * 
 * @author ELCOT
 *
 */
public class TestRespondentService {

	static final Logger log = Logger.getLogger(TestRespondentService.class);

	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Valid User Name")
	void testUserNameValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(true, service.userNameValidation("qwerty"));
	}

	@Test
	@DisplayName("Invalid User Name")
	void testUserNameValidation1() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(false, service.userNameValidation("qwerty123#$"));
	}

	@Test
	@DisplayName(" Valid surveyId")
	void testUserIdValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(true, service.idValidation("1"));
	}

	@Test
	@DisplayName("InValid surveyId")
	void testUserIdValidation1() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(false, service.idValidation("1wsd"));
	}

	@Test
	@DisplayName("Valid Answer")
	void testAnswerValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(true, service.answerValidation("1"));
	}

	@Test
	@DisplayName("Invalid Answer")
	void testAnswerValidation1() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(false, service.answerValidation("5"));
	}

	@Test
	@DisplayName("Valid Password")
	void testPasswordValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(true, service.passwordValidation("qwerty"));
	}

	@Test
	@DisplayName("InValid Password")
	void testPasswordValidation1() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(false, service.passwordValidation("qwerty%"));
	}

	@Test
	@DisplayName("Valid ContactNumber")
	void testContactNoValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(true, service.contactNumberValidation("9965749280"));
	}

	@Test
	@DisplayName("InValid ContactNumber")
	void testContactNoValidation1() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(false, service.contactNumberValidation("99657492801"));
	}

	@Test
	@DisplayName("Valid choice Respondent")
	void testChoiceValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(true, service.choiceRespondentValidation("1"));
	}

	@Test
	@DisplayName("InValid choice Respondent")
	void testChoiceValidation1() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(false, service.choiceRespondentValidation("1a"));
	}

	@Test
	@DisplayName("Valid Respondent Name")
	void testNameValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(true, service.nameValidation("qwerty"));
	}

	@Test
	@DisplayName("InValid Respondent Name")
	void testNameValidation1() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertEquals(false, service.nameValidation("qwerty123"));
	}

	@Test
	@DisplayName(" Respondent Registration")
	void testRespondentRegistrationValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		RespondentInfoBean bean = FactoryClass.getRespondentBeanInstance();
		bean.setrespondentId("1");
		bean.setrespondentFirstName("Praba");
		bean.setrespondentLastName("karan");
		bean.setrespondentPassword("1234");
		bean.setrespondentContact("9965749280");

		ArrayList<RespondentInfoBean> respondent = new ArrayList<>();
		respondent.add(bean);
		assertEquals(true, service.getRespondentRegistration(respondent));
	}

	@Test
	@DisplayName("Add Responses")
	void testRespondentAddValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		CreateRespondentDetailsBean bean = FactoryClass.getRespondentDetailsBean();
		bean.setquestionOneAnswerOne("hai");
		bean.setrespondentId("1");
		bean.setquestionId("1");

		ArrayList<CreateRespondentDetailsBean> respondent = new ArrayList<>();
		respondent.add(bean);
		assertEquals(true, service.getResponsesAdd(respondent));
	}

	@Test
	@DisplayName("View  the responses")
	void testGetResponsesValidation() {
		RespondentService service = FactoryClass.getRespondentServInstance();
		assertNotNull(service.getResponse("1"));
	}
}
