package com.capgemini.surveyappl.service;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import com.capgemini.surveyappl.factory.FactoryClass;

/**
 * This is test class of admin service side.
 * 
 * @author ELCOT
 *
 */
public class TestAdminService {

	static final Logger log = Logger.getLogger(TestAdminService.class);

	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Valid ChoiceCheckValidation")
	void testChoiceValidation() {
		AdminService service = FactoryClass.getAdminSeviceInstance();
		assertEquals(true, service.choiceCheckValidation("1"));
	}

	@Test
	@DisplayName("Invalid ChoiceCheckValidation")
	void testChoiceValidation1() {
		AdminService service = FactoryClass.getAdminSeviceInstance();
		assertEquals(false, service.choiceCheckValidation("q"));
	}

	@Test
	@DisplayName("admin Login")
	void testAdminLogin() {
		AdminService service = FactoryClass.getAdminSeviceInstance();
		assertEquals(true, service.getAdminLogin("admin", "12345"));
	}

}
