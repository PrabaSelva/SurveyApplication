package com.capgemini.surveyappl.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.SurveyorInfoBean;
import com.capgemini.surveyappl.factory.FactoryClass;

/**
 * This is test class of surveyordao side.
 * 
 * @author ELCOT
 *
 */

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TestSurveyorDAO {

	static final Logger log = Logger.getLogger(TestSurveyorDAO.class);

	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Add the survey")
	void testUserNameValidation() {
		SurveyorDAO surveyDao = FactoryClass.getSurveyorDaoInstance();
		CreateSurveyDetailsBean survey = FactoryClass.getCreateSurveyDetails();
		survey.setid("4");
		survey.setname("java");
		survey.setdescription("survey");
		survey.setStartDate(LocalDate.of(1998, 03, 11));
		survey.setStartDate(LocalDate.of(1998, 03, 11));
		survey.setquestionHasOneOption("qwerty");
		survey.setquestionOneOptionOne("a");
		survey.setquestionOneOptionTwo("b");
		survey.setquestionOneOptionThree("c");
		survey.setquestionOneOptionFour("d");
		survey.setquestionHasMultipleOption("qwerty1");
		survey.setquestionTwoOptionOne("a");
		survey.setquestionTwoOptionTwo("b");
		survey.setquestionTwoOptionThree("c");
		survey.setquestionTwoOptionFour("d");

		ArrayList<CreateSurveyDetailsBean> surveylist = new ArrayList<>();
		surveylist.add(survey);
		assertEquals(true, surveyDao.getSurveyadd(surveylist));
	}

	@Test
	@DisplayName("Surveyor registration")
	void testRegsSurveyValidation() {
		SurveyorDAO survey = FactoryClass.getSurveyorDaoInstance();
		SurveyorInfoBean bean = FactoryClass.getSurveyorBeanInstance();

		bean.setuserId("respondent");
		bean.setfirstName("Praba");
		bean.setlastName("Karan");
		bean.setcontactNumber("9965749280");
		bean.setpassword("12345");

		ArrayList<SurveyorInfoBean> surveylist = new ArrayList<>();
		surveylist.add(bean);
		assertEquals(true, survey.getSurveyorRegistration(surveylist));
	}

	@Test
	@DisplayName("Valid surveyid to update")
	void testUpdateSurveyValidation() {
		SurveyorDAO survey = FactoryClass.getSurveyorDaoInstance();
		assertEquals(true, survey.getSurveyUpdate("2"));

	}

	@Test
	@DisplayName("Valid surveyId to delete")
	void testDeleteSurveyValidation() {
		SurveyorDAO survey = FactoryClass.getSurveyorDaoInstance();
		assertEquals(true, survey.getDeleteSurvey("1"));
	}

	@BeforeAll
	@DisplayName("Valid surveyId to view")
	void testLoginSurveyValidation() {
		SurveyorDAO survey = FactoryClass.getSurveyorDaoInstance();
		assertNotNull(survey.getViewSurvey("1"));
	}

	@Test
	@DisplayName("Invalid Check Survey")
	void testCheckSurvey1() {
		SurveyorDAO survey = FactoryClass.getSurveyorDaoInstance();
		assertEquals(false, survey.getcheckSurvey("4a"));
	}
}
