package com.capgemini.surveyappl.service;

import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyappl.factory.FactoryClass;

public class TestControllerService {

	static final Logger log = Logger.getLogger(TestControllerService.class);

	Scanner sc = new Scanner(System.in);

	@Test
	@DisplayName("Valid ChoiceCheckValidation")
	void testChoiceValidation() {
		ControllerService service = FactoryClass.getcontrollerServiceInstance();
		assertEquals(true, service.choiceCheckValidation("1"));
	}

	@Test
	@DisplayName("Invalid ChoiceCheckValidation")
	void testChoiceValidation1() {
		ControllerService service = FactoryClass.getcontrollerServiceInstance();
		assertEquals(false, service.choiceCheckValidation("abc"));
	}
}
