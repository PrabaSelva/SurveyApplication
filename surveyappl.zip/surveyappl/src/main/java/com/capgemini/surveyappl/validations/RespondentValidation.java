package com.capgemini.surveyappl.validations;

/**
 * This is respondent Validation Interface is used to give implementation to
 * implementation of respondent validation class
 * 
 * @author ELCOT
 *
 */
public interface RespondentValidation {

	public boolean answerValidation(String answer);

	public boolean singleLineQuestionValidation(String singleline);

	public boolean multipleLineQuestionValidation(String multipleline);

	public boolean choiceRespondentValidation(String responsesresponses);

	public boolean passwordValidation(String password);

	boolean idValidation(String surveyId);

	public boolean userNameValidation(String respondentName);

	public boolean nameValidation(String name);

	public boolean contactNumberValidation(String contactNumber);
}
