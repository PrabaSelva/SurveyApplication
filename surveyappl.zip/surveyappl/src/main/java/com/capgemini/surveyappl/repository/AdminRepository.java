package com.capgemini.surveyappl.repository;

import java.util.ArrayList;
import java.util.List;
import com.capgemini.surveyappl.bean.AdminInfoBean;
import com.capgemini.surveyappl.factory.FactoryClass;

/**
 * This is admin repository class
 * 
 * @author ELCOT
 *
 */
public class AdminRepository {

	static List<AdminInfoBean> admin = new ArrayList<>();

	/**
	 * This method is uesd to get the admin login data from repository class
	 * 
	 * @return admininfo
	 */
	public List<AdminInfoBean> adminInfoBean() {

		List<AdminInfoBean> admininfo = new ArrayList<>();

		AdminInfoBean adminBean = FactoryClass.getAdminBeanInstance();

		adminBean.setadminUserName("admin");
		adminBean.setadminPassword("12345");

		admininfo.add(adminBean);
		return admininfo;
	}
}
