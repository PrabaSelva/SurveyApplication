package com.capgemini.surveyappl.exception;

import org.apache.log4j.Logger;

/**
 * This class is used to show exception for invalid survey MisMatch login
 * details.
 * 
 * @author ELCOT
 *
 */
public class InvalidSurveyorMisMatchException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(InvalidSurveyorMisMatchException.class);

	String message = " Surveyor Login failed......\n";

	/**
	 * This returns exception message
	 * 
	 * @return message
	 */
	public String exceptionMessage() {
		return message;
	}
}
