package com.capgemini.surveyappl.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is used to perform all validations of admin side.
 * 
 * @author ELCOT
 *
 */
public class AdminValidationImplement implements AdminValidation {

	Pattern pattn = null;
	Matcher mattn = null;

	/**
	 * This choice check validation method
	 * 
	 * @return true or false
	 * @param extractPerson
	 */
	@Override
	public boolean choiceCheckValidation(String extractPerson) {
		pattn = Pattern.compile("[1-5]");
		mattn = pattn.matcher(extractPerson);
		return mattn.matches();
	}

}
