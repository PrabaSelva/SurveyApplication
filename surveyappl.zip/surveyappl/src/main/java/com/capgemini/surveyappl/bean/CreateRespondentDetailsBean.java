package com.capgemini.surveyappl.bean;

import java.io.Serializable;

/**
 * It is respondent class for set and get the values
 * 
 * @author ELCOT
 *
 */

public class CreateRespondentDetailsBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String questionId;

	private String questionOneAnswerOne;

	private String[] finalResult;

	private String respondentId;

	private String[] arrayList;

	public CreateRespondentDetailsBean() {

	}

	public String getquestionOneAnswerOne() {
		return questionOneAnswerOne;
	}

	public void setquestionOneAnswerOne(String answerOne) {
		questionOneAnswerOne = answerOne;
	}

	public String getquestionId() {
		return questionId;
	}

	public void setquestionId(String question) {
		this.questionId = question;
	}

	public String[] getarrayList() {
		return arrayList;
	}

	public void setarrayList(String[] result) {
		this.arrayList = result;
	}

	public String[] getfinalResult() {
		return finalResult;
	}

	public void setfinalResult(String[] finalResults) {
		this.finalResult = finalResults;
	}

	public String getrespondentId() {
		return respondentId;
	}

	public void setrespondentId(String respondentIdOne) {
		this.respondentId = respondentIdOne;
	}

}
