package com.capgemini.surveyappl.exception;

import org.apache.log4j.Logger;

/**
 * This class for finding survey details in list
 * 
 * @author ELCOT
 *
 */
public class InvalidNoSurveyFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(InvalidNoSurveyFoundException.class);

	String message = "No Survey Found in the List......\n";

	/**
	 * This returns exception message
	 * 
	 * @return message
	 */
	public String exceptionMessage() {
		return message;
	}
}
