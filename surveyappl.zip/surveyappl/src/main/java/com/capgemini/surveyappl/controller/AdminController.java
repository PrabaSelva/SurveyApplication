package com.capgemini.surveyappl.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveyappl.exception.InvalidAdminMisMatchException;
import com.capgemini.surveyappl.factory.FactoryClass;
import com.capgemini.surveyappl.service.AdminService;
import com.capgemini.surveyappl.service.AdminServiceImplement;

/**
 * This class is used to perform all basic operations of admin here...
 * 
 * @author ELCOT
 *
 */
public class AdminController {

	AdminService adminService = new AdminServiceImplement();

	static final Logger logg = Logger.getLogger(AdminController.class);

	Scanner scann = new Scanner(System.in);

	/**
	 * This admin login method
	 */
	public void adminControllerLogin() {

		Properties file = new Properties();

		try {
			file.load(new FileInputStream("LoginCredentials.properties"));
		} catch (IOException e) {
			e.getMessage();
		}

		String adminId = file.getProperty("adminId");

		String adminPassword = file.getProperty("adminPassword");

		try {

			boolean adminlogin = adminService.getAdminLogin(adminId, adminPassword);
			if (adminlogin) {

				logg.info(" login successful\n");

				FactoryClass.getAdminControllerInstance().getAdminServicePart();

			}

		} catch (InvalidAdminMisMatchException e) {
			logg.error(e.exceptionMessage());

		}
	}

	/**
	 * This service method is used to choose valid options for performing the task
	 */
	private void getAdminServicePart() {

		boolean flag = true;

		do {
			logg.info("****************Press the enter required following options*****************");
			logg.info("1.Surveyor Portal");
			logg.info("2.Respondent Portal");
			logg.info("3.Add Surveyor");
			logg.info("4.Add Respondent");
			logg.info("5.Exit\n");

			logg.info("Enter the Option..[1-5]");
			String extractPerson = scann.nextLine();
			while (!adminService.choiceCheckValidation(extractPerson)) {
				logg.info("Enter the valid Option..[1-5]");
				extractPerson = scann.nextLine();
			}

			int adminServiceOne = Integer.parseInt(extractPerson);

			switch (adminServiceOne) {
			case 1:

				SurveyorController surveycontrol = FactoryClass.getSurveyorControllerInstance();
				surveycontrol.surveyorControllerLogin();
				break;
			case 2:

				RespondentController respondentcontrol = FactoryClass.getRespondentServiceInstance();
				respondentcontrol.respControllerLoginCredentials();
				break;
			case 3:

				logg.info(".........Add Surveyor.........");
				SurveyorController surveyregis = FactoryClass.getSurveyorControllerInstance();
				surveyregis.surveyRegistration();
				break;
			case 4:

				logg.info("...........Add Respondent........");
				RespondentController respondentregis = FactoryClass.getRespondentServiceInstance();
				respondentregis.respondentRegistration();
				break;
			case 5:

				flag = false;
				break;
			default:
				// No process taken here
			}

		} while (flag);

	}

}
