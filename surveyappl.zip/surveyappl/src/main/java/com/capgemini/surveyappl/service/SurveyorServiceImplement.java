package com.capgemini.surveyappl.service;

import java.util.ArrayList;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.SurveyorInfoBean;
import com.capgemini.surveyappl.dao.SurveyorDAO;
import com.capgemini.surveyappl.dao.SurveyorDAOImplement;
import com.capgemini.surveyappl.validations.SurveyorValidation;
import com.capgemini.surveyappl.validations.SurveyorValidationImplement;

/**
 * 
 * This class is used to perform validation and establishing connection to
 * surveyor dao side.
 * 
 * @author ELCOT
 *
 */
public class SurveyorServiceImplement implements SurveyorService {

	SurveyorValidation inputValid = new SurveyorValidationImplement();

	SurveyorDAO surveyordao = new SurveyorDAOImplement();

	/**
	 * This method is used to choice Check validation in survey
	 * 
	 * @param extractperson1
	 * 
	 * @return true or false
	 */

	@Override
	public boolean choiceCheckValidateOne(String extractPerson) {

		if (extractPerson != null) {
			return inputValid.choiceCheckValidation(extractPerson);
		}

		return false;

	}

	/**
	 * This method is used to check id Validation
	 * 
	 * @param surveyid
	 * @return true or false
	 */
	@Override
	public boolean idValidation(String surveyId) {

		if (surveyId != null) {
			return inputValid.idValidation(surveyId);
		}

		return false;

	}

	/**
	 * This method is used to check name Validation
	 * 
	 * @param surveyName
	 * @return true or false
	 */
	@Override
	public boolean nameValidation(String surveyName) {

		if (surveyName != null) {
			return inputValid.nameValidation(surveyName);
		}

		return false;

	}

	/**
	 * This method is used to check start date Validation
	 * 
	 * @param surveyStartDate
	 * @return true or false
	 */
	@Override
	public boolean startDateValidation(String surveyStartDate) {

		if (surveyStartDate != null) {
			return inputValid.startDateValidation(surveyStartDate);
		}

		return false;

	}

	/**
	 * This method is used to check end date Validation
	 * 
	 * @param surveyEndDate
	 * @return true or false
	 */
	@Override
	public boolean endDateValidation(String surveyEndDate) {

		if (surveyEndDate != null) {
			return inputValid.endDateValidation(surveyEndDate);
		}

		return false;

	}

	/**
	 * This method is used to check option Validation
	 * 
	 * @param q1option1
	 * @return true or false
	 */
	@Override
	public boolean optionValidation(String option) {

		if (option != null) {
			return inputValid.optionValidation(option);
		}

		return false;

	}

	/**
	 * This method is used to delete survey
	 * 
	 * @param surveyid
	 * @return true or false
	 */
	@Override
	public boolean deleteSurvey(String surveyId) {

		if (surveyId != null) {
			return surveyordao.getDeleteSurvey(surveyId);
		}

		return false;
	}

	/**
	 * This method is used to check choice validation
	 * 
	 * @param choice
	 * @return true or false
	 */
	@Override
	public boolean choiceCheckValidate(String choice) {

		if (choice != null) {
			return inputValid.choiceCheckValidate(choice);
		}

		return false;

	}

	/**
	 * This method is used to update the survey
	 * 
	 * @param surveyid
	 * @return true or false
	 */
	@Override
	public boolean getUpdateSurvey(String surveyId) {

		if (surveyId != null) {
			return surveyordao.getSurveyUpdate(surveyId);
		}

		return false;

	}

	/**
	 * This method is used to check the username
	 * 
	 * @param id
	 * @return true or false
	 */
	@Override
	public boolean userNameValidation(String id) {

		if (id != null) {
			return inputValid.userNameValidation(id);
		}

		return false;

	}

	/**
	 * This method is used to check password validation
	 * 
	 * @param surveypassword
	 * @return true or false
	 */
	@Override
	public boolean passwordValidation(String password) {

		if (password != null) {
			return inputValid.passwordValidation(password);
		}

		return false;

	}

	/**
	 * This method is used to check contact Validation
	 * 
	 * @param contactNo
	 * @return true or false
	 */
	@Override
	public boolean contactNumberValidation(String contactNumber) {

		if (contactNumber != null) {
			return inputValid.contactNumberValidation(contactNumber);
		}

		return false;

	}

	/**
	 * This method is used to get survey Registration
	 * 
	 * @param surveyreglist
	 * @return true or false
	 */
	@Override
	public boolean getSurveyorRegistration(ArrayList<SurveyorInfoBean> surveyorRegistrationList) {

		if (surveyorRegistrationList != null) {
			return surveyordao.getSurveyorRegistration(surveyorRegistrationList);
		}

		return false;
	}

	/**
	 * This method is used to login of surveyor
	 * 
	 * @return true or false
	 * @param surveyorid.surveyPassword
	 */
	@Override
	public boolean getLogin(String surveyorId, String surveyPassword) {

		if ((surveyorId != null) && (surveyPassword != null)) {
			return surveyordao.getLoginSurvey(surveyorId, surveyPassword);
		}

		return false;
	}

	/**
	 * This method is used to check survey description
	 * 
	 * @return true or false
	 * @param surveyDescription
	 */
	@Override
	public boolean surveyDescriptionValidation(String surveyDescription) {

		if (surveyDescription != null) {
			return inputValid.descriptionValidation(surveyDescription);
		}

		return false;

	}

	/**
	 * This method is used to check thesurvey questions
	 * 
	 * @return true or false
	 * @param question1
	 */
	@Override
	public boolean questionValidation(String question) {

		if (question != null) {
			return inputValid.questionValidation(question);
		}

		return false;
	}

	/**
	 * This method is used to check the first and last name validations.
	 * 
	 * @return true or false
	 * @param question1
	 */
	@Override
	public boolean firstLastNameValidation(String firstLastName) {

		if (firstLastName != null) {
			return inputValid.firstLastNameValidation(firstLastName);
		}

		return false;
	}

	/**
	 * This method is used to view the survey
	 * 
	 * @param surveyid
	 * @return true or false
	 */
	@Override
	public CreateSurveyDetailsBean viewSurvey(String surveyId) {
		return surveyordao.getViewSurvey(surveyId);
	}

	/**
	 * This method is used to add survey list
	 * 
	 * @param surveylist
	 * @return true or false
	 */
	@Override
	public boolean getSurveyorDaoAdd(ArrayList<CreateSurveyDetailsBean> surveyList) {

		if (surveyList != null) {
			return surveyordao.getSurveyadd(surveyList);
		}

		return false;
	}

	/**
	 * This method is used to check survey is present or not in the list
	 * 
	 * @return true or false
	 * @param surveyId
	 */
	@Override
	public boolean checkSurvey(String surveyId) {
		if (surveyId != null) {
			return surveyordao.getcheckSurvey(surveyId);
		}
		return false;
	}

}
