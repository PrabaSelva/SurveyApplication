package com.capgemini.surveyappl.service;

import java.util.ArrayList;

import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.RespondentInfoBean;
import com.capgemini.surveyappl.dao.RespondentDAO;
import com.capgemini.surveyappl.dao.RespondentDAOImplement;
import com.capgemini.surveyappl.exception.SurveyIdNotFoundException;
import com.capgemini.surveyappl.validations.RespondentValidation;
import com.capgemini.surveyappl.validations.RespondentValidationImplement;

/**
 * This class is used to perform validation and establishing connection to
 * respondent dao side.
 * 
 * @author ELCOT
 *
 */
public class RespondentServiceImplement implements RespondentService {

	RespondentValidation respondValid = new RespondentValidationImplement();

	RespondentDAO respondentdao = new RespondentDAOImplement();

	/**
	 * This method is used to check user name validation
	 * 
	 * @param respondentname
	 * @return true or false
	 */
	@Override
	public boolean userNameValidation(String respondentName) {

		if (respondentName != null) {
			return respondValid.userNameValidation(respondentName);
		}

		return false;

	}

	/**
	 * This method is used to check password validation
	 * 
	 * @param password
	 * @return true or false
	 */
	@Override
	public boolean passwordValidation(String password) {

		if (password != null) {
			return respondValid.passwordValidation(password);
		}

		return false;

	}

	/**
	 * This method is used to check id validation
	 * 
	 * @param surveyid
	 * @return true or false
	 */
	@Override
	public boolean idValidation(String surveyId) {

		if (surveyId != null) {
			return respondValid.idValidation(surveyId);
		}

		return false;

	}

	/**
	 * This method is used to choice response validation
	 * 
	 * @param responses
	 * @return true or false
	 */
	@Override
	public boolean choiceRespondentValidation(String responses) {

		if (responses != null) {
			return respondValid.choiceRespondentValidation(responses);
		}

		return false;

	}

	/**
	 * This method is used answer validation
	 * 
	 * @param ans
	 * @return true or false
	 */
	@Override
	public boolean answerValidation(String answer) {

		if (answer != null) {
			return respondValid.answerValidation(answer);
		}

		return false;

	}

	/**
	 * This method is used to add the responses
	 * 
	 * @param sl
	 * @return true or false
	 */
	@Override
	public boolean getResponsesAdd(ArrayList<CreateRespondentDetailsBean> list) {

		if (list != null) {
			return respondentdao.getResponseAdd(list);
		}

		return false;

	}

	/**
	 * This method is used to name validation
	 * 
	 * @param fname
	 * @return true or false
	 */
	@Override
	public boolean nameValidation(String firstName) {

		if (firstName != null) {
			return respondValid.nameValidation(firstName);
		}

		return false;

	}

	/**
	 * This method is used to Contact Number validation
	 * 
	 * @param contactNo
	 * @return true or false
	 */
	@Override
	public boolean contactNumberValidation(String contactNumber) {

		if (contactNumber != null) {
			return respondValid.contactNumberValidation(contactNumber);
		}

		return false;

	}

	/**
	 * This method is used to get respondent registration
	 * 
	 * @param reglist
	 * @return true or false
	 */
	@Override
	public boolean getRespondentRegistration(ArrayList<RespondentInfoBean> registrationList) {

		if (registrationList != null) {
			return respondentdao.getRespondentRegistration(registrationList);
		}

		return false;
	}

	/**
	 * This method is used to get the respondent login
	 * 
	 * @return true or false
	 * @param id,password
	 */
	@Override
	public boolean getRespondentLogin(String id, String password) {

		if ((id != null) && (password != null)) {
			return respondentdao.getRespondentLogin(id, password);
		}

		return false;
	}

	/**
	 * This method is used to get response
	 * 
	 * @param surveyid
	 * @throws SurveyIdNotFoundException
	 * @return CreateSurveyDetailsBean
	 */
	@Override
	public CreateSurveyDetailsBean getResponse(String surveyId) {

		return respondentdao.getResponseOfRespondent(surveyId);

	}

}
