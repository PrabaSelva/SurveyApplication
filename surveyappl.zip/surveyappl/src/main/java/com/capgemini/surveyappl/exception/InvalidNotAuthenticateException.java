package com.capgemini.surveyappl.exception;

import org.apache.log4j.Logger;

/**
 * This class is used for creation of exception for unauthorised respondent for
 * particular survey
 * 
 * @author ELCOT
 *
 */
public class InvalidNotAuthenticateException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(InvalidNotAuthenticateException.class);

	String message = "You will not have the permission to access this survey ......\n";

	/**
	 * It returns the exception message
	 * 
	 * @return message
	 */
	public String exceptionMessage() {
		return message;
	}
}
