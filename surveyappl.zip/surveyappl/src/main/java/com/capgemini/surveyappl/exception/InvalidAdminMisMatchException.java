package com.capgemini.surveyappl.exception;

import org.apache.log4j.Logger;

/**
 * This class is used to find admin login details
 * 
 * @author ELCOT
 *
 */
public class InvalidAdminMisMatchException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(InvalidAdminMisMatchException.class);

	String message = "Admin Login failed......\n";

	/**
	 * This returns exception message
	 * 
	 * @return message
	 */
	public String exceptionMessage() {
		return message;
	}
}
