package com.capgemini.surveyappl.dao;

/**
 * This is adminDao interface is provide implementation to adminDao
 * Implementation class
 * 
 * @author ELCOT
 *
 */
public interface AdminDAO {

	boolean getAdminLogin(String adminId, String adminPassword);
}
