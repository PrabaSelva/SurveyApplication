package com.capgemini.surveyappl.service;

/**
 * This is interface is used to give implementation to AdminService
 * Implementation class
 * 
 * @author ELCOT
 *
 */
public interface AdminService {

	boolean choiceCheckValidation(String extractPerson);

	boolean getAdminLogin(String adminId, String adminPassword);

}
