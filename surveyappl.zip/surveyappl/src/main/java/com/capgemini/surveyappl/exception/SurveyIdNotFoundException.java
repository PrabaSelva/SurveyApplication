package com.capgemini.surveyappl.exception;

import org.apache.log4j.Logger;

/**
 * This class is used to finding survey id in the list.
 * 
 * @author ELCOT
 *
 */
public class SurveyIdNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(SurveyIdNotFoundException.class);

	String message = "surveyor Id is not found...\n";

	/**
	 * This returns exception message
	 * 
	 * @return message
	 */
	public String exceptionMessage() {
		return message;
	}
}
