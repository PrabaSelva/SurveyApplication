package com.capgemini.surveyappl.bean;

import java.io.Serializable;

/**
 * The admin info class for set and get the values
 * 
 * @author ELCOT
 *
 */

public class AdminInfoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String adminUserName;

	private String adminPassword;

	public AdminInfoBean() {

	}

	public String getadminUserName() {
		return adminUserName;
	}

	public void setadminUserName(String adminusername1) {
		adminUserName = adminusername1;
	}

	public String getadminPassword() {
		return adminPassword;
	}

	public void setadminPassword(String adminpassword1) {
		adminPassword = adminpassword1;
	}

}
