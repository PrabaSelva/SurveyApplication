package com.capgemini.surveyappl.validations;

/**
 * This interface is used to give implementation to adminimplementation class.
 * 
 * @author ELCOT
 *
 */
public interface AdminValidation {

	boolean choiceCheckValidation(String extractPerson);

}
