package com.capgemini.surveyappl.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.RespondentInfoBean;
import com.capgemini.surveyappl.factory.FactoryClass;

/**
 * This is Respondent Repository class
 * 
 * @author ELCOT
 *
 */
public class RespondentRepository {

	static List<RespondentInfoBean> respondent = new ArrayList<>();

	static List<CreateRespondentDetailsBean> respondentOne = new ArrayList<>();

	/**
	 * This method is used to give dummy data for respondent login
	 * 
	 * @return respondent
	 */
	public List<RespondentInfoBean> respondentBean() {

		List<RespondentInfoBean> respondentMain = new ArrayList<>();
		List<RespondentInfoBean> respondentInfo = new ArrayList<>();

		RespondentInfoBean respondentBean = FactoryClass.getRespondentBeanInstance();

		respondentBean.setrespondentId("respondent");
		respondentBean.setrespondentPassword("12345");
		respondentInfo.add(respondentBean);

		RespondentInfoBean respondentBeanOne = FactoryClass.getRespondentBeanInstance();

		respondentBeanOne.setrespondentId("respond");
		respondentBeanOne.setrespondentPassword("123");

		respondentInfo.add(respondentBeanOne);

		respondentMain.addAll(respondentInfo);

		return respondentMain;

	}

	/**
	 * This method is used to give dummy data for respondent responses
	 * 
	 * @return respondent1
	 */

	public List<CreateRespondentDetailsBean> respondentDetails() {

		List<CreateRespondentDetailsBean> respondentMain = new ArrayList<>();
		List<CreateRespondentDetailsBean> respondentlist = new ArrayList<>();

		CreateRespondentDetailsBean respondentBean = FactoryClass.getRespondentDetailsBean();

		respondentBean.setquestionOneAnswerOne("ooty");
		String[] array = { "Parks", "Gardens" };
		respondentBean.setquestionId("1");
		respondentBean.setfinalResult(array);

		respondentlist.add(respondentBean);

		CreateRespondentDetailsBean respondentBeanOne = FactoryClass.getRespondentDetailsBean();
		respondentBeanOne.setquestionOneAnswerOne("good");
		String[] a1 = { "ventilator", "cholestoral checker" };
		respondentBeanOne.setquestionId("2");
		respondentBeanOne.setfinalResult(a1);

		respondentlist.add(respondentBeanOne);

		respondentMain.addAll(respondentlist);

		return respondentMain;
	}
}
