package com.capgemini.surveyappl.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is used to perform validation in surveyor side.
 * 
 * @author ELCOT
 *
 */
public class SurveyorValidationImplement implements SurveyorValidation {

	Pattern pattn = null;
	Matcher mattn = null;

	/**
	 * this method is used to check startDate validation
	 * 
	 * @param surveystartDate
	 * 
	 * @return true or false
	 */
	@Override
	public boolean startDateValidation(String surveyStartDate) {
		pattn = Pattern.compile("^((19|2[0-9])[0-9]{2})-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$");
		mattn = pattn.matcher(surveyStartDate);
		return mattn.matches();
	}

	/**
	 * This method is used to check the endDate validation
	 * 
	 * @param surveyendDate
	 * @return true or false
	 * 
	 */
	@Override
	public boolean endDateValidation(String surveyEndDate) {
		pattn = Pattern.compile("^((19|2[0-9])[0-9]{2})-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$");
		mattn = pattn.matcher(surveyEndDate);
		return mattn.matches();
	}

	/**
	 * This method is used to check id validation
	 * 
	 * @param surveyid
	 *            return true or false
	 */
	@Override
	public boolean idValidation(String surveyId) {
		pattn = Pattern.compile("\\d{1,5}");
		mattn = pattn.matcher(surveyId);
		return mattn.matches();
	}

	/**
	 * this method is used to check username validation
	 * 
	 * @param surveyName
	 * @return true or false
	 */
	public boolean userNameValidation(String userName) {
		pattn = Pattern.compile("[a-zA-Z0-9]{5,10}");
		mattn = pattn.matcher(userName);
		return mattn.matches();
	}

	/**
	 * This method is used to check name validation
	 * 
	 * @param surveyName
	 * @return true or false
	 */

	public boolean nameValidation(String surveyName) {
		pattn = Pattern.compile("[a-zA-Z]+[\\s[[a-zA-Z]+]]*");
		mattn = pattn.matcher(surveyName);
		return mattn.matches();
	}

	/**
	 * This method is used to check question id validations
	 * 
	 * @param questionsid
	 * @return true or false
	 */
	public boolean questionsIdValidation(String question) {
		pattn = Pattern.compile("\\d{1,3}");
		mattn = pattn.matcher(question);
		return mattn.matches();
	}

	/**
	 * This method is used to check choice Validations
	 * 
	 * @param choice
	 * @retun true or false
	 */
	public boolean choiceCheckValidate(String choice) {
		pattn = Pattern.compile("[1-3]");
		mattn = pattn.matcher(choice);
		return mattn.matches();
	}

	/**
	 * This method is used to check the view Validations
	 * 
	 * @param s
	 * @return true or false
	 */
	public boolean viewValidation(String s) {
		pattn = Pattern.compile("[1-2]");
		mattn = pattn.matcher(s);
		return mattn.matches();
	}

	/**
	 * This method is used to check the password validations
	 * 
	 * @param password
	 * @return true or false
	 */
	@Override
	public boolean passwordValidation(String password) {
		pattn = Pattern.compile("[a-zA-Z0-9@$]+");
		mattn = pattn.matcher(password);
		return mattn.matches();
	}

	/**
	 * This method is used to check the contactNumber
	 * 
	 * @param contactNo
	 * @return true or false
	 */
	@Override
	public boolean contactNumberValidation(String contactNumber) {
		pattn = Pattern.compile("[6-9][0-9]{9}");
		mattn = pattn.matcher(contactNumber);
		return mattn.matches();
	}

	/**
	 * This method is used to check the option validation
	 * 
	 * @param qO1
	 * @return true or false
	 */
	@Override
	public boolean optionValidation(String option) {
		pattn = Pattern.compile("[a-zA-Z]+[\\s[[a-zA-Z]+]]*");
		mattn = pattn.matcher(option);
		return mattn.matches();
	}

	/**
	 * This method is used to check the choice validation
	 * 
	 * @param extractPerson1
	 * @return true or false
	 */
	@Override
	public boolean choiceCheckValidation(String extractPerson) {
		pattn = Pattern.compile("[1-7]");
		mattn = pattn.matcher(extractPerson);
		return mattn.matches();
	}

	/**
	 * This method is used to check the survey decription validation
	 * 
	 * @param surveyDescription
	 * @return true or false
	 * 
	 */
	@Override
	public boolean descriptionValidation(String surveyDescription) {
		pattn = Pattern.compile("[a-zA-Z]+[\\s[[a-zA-Z]+]]*");
		mattn = pattn.matcher(surveyDescription);
		return mattn.matches();
	}

	/**
	 * This method is used to check the survey question validation
	 * 
	 * @param question1
	 * @return true or false
	 */
	@Override
	public boolean questionValidation(String question) {
		pattn = Pattern.compile("^[a-zA-Z]+[\\s[[a-zA-Z]+]]*");
		mattn = pattn.matcher(question);
		return mattn.matches();
	}

	/**
	 * This method is used to check the first and last name validation
	 * 
	 * @param sFirstName
	 * @return true or false
	 */
	@Override
	public boolean firstLastNameValidation(String name) {
		pattn = Pattern.compile("[a-zA-Z]+");
		mattn = pattn.matcher(name);
		return mattn.matches();
	}
}
