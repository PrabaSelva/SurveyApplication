package com.capgemini.surveyappl.controller;

import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveyappl.factory.FactoryClass;
import com.capgemini.surveyappl.service.ControllerService;
import com.capgemini.surveyappl.service.ControllerServiceImplement;

/**
 * The Starting point of the project begins here.
 * 
 * @author ELCOT
 */
public class MainController {

	static final Logger logg = Logger.getLogger(MainController.class);

	static Scanner scann = new Scanner(System.in);

	public static void main(String[] args) {

		ControllerService loginservice = new ControllerServiceImplement();
		boolean flag = true;

		do {
			logg.info(" ");

			logg.info("*********************HI WELCOME TO SURVEY APP******************");
			logg.info(" ");
			logg.info("Please tell us,  Who are you........?");
			logg.info("1.Administrator");
			logg.info("2.Surveyor");
			logg.info("3.Responder");
			logg.info("4.Exit\n");

			logg.info("Enter the Option...[1-4]");

			String extractPerson = scann.nextLine();

			while (!loginservice.choiceCheckValidation(extractPerson)) {
				logg.info("Enter the valid Option...[1-4]");
				extractPerson = scann.nextLine();
			}

			int surveyorLogin = Integer.parseInt(extractPerson);

			switch (surveyorLogin) {
			case 1:
				AdminController admincontrol = FactoryClass.getAdminControllerInstance();
				admincontrol.adminControllerLogin();
				break;
			case 2:
				SurveyorController surveyorcontrol = FactoryClass.getSurveyorControllerInstance();
				surveyorcontrol.surveyorControllerLogin();
				break;
			case 3:
				RespondentController respondentcontrol = FactoryClass.getRespondentServiceInstance();
				respondentcontrol.respControllerLoginCredentials();
				break;
			case 4:
				logg.info("******************Thanks for using this SurveyApp******************");
				flag = false;
				break;
			default:
				// No process taken here
			}
		} while (flag);
		scann.close();
	}
}
