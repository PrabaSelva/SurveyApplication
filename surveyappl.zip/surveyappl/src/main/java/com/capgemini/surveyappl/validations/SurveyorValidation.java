package com.capgemini.surveyappl.validations;

/**
 * This is interface to used to provide implementation to SurveyorValidation
 * Implementation class
 * 
 * @author ELCOT
 *
 */
public interface SurveyorValidation {

	boolean startDateValidation(String surveyStartDate);

	boolean endDateValidation(String surveyStartDate);

	boolean idValidation(String surveyId);

	boolean questionsIdValidation(String question);

	public boolean nameValidation(String surveyName);

	public boolean choiceCheckValidate(String choice);

	boolean passwordValidation(String password);

	boolean contactNumberValidation(String contactNumber);

	public boolean userNameValidation(String userName);

	boolean optionValidation(String option);

	boolean choiceCheckValidation(String extractPerson);

	boolean descriptionValidation(String surveyDescription);

	boolean questionValidation(String question);

	boolean firstLastNameValidation(String name);

}
