package com.capgemini.surveyappl.service;

/**
 * This is interface gives implementation to controller service implementation
 * class
 * 
 * @author ELCOT
 *
 */
public interface ControllerService {

	boolean choiceCheckValidation(String extractPerson);

}
