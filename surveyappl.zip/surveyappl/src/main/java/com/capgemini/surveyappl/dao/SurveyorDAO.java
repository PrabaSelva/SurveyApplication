package com.capgemini.surveyappl.dao;

import java.util.List;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.SurveyorInfoBean;

/**
 * This is interface is used to provide implementation to surveyor Dao
 * Implementation class
 * 
 * @author ELCOT
 *
 */
public interface SurveyorDAO {

	public boolean getSurveyadd(List<CreateSurveyDetailsBean> surveyList);

	public boolean getSurveyUpdate(String surveyId);

	public boolean getDeleteSurvey(String surveyId);

	public CreateSurveyDetailsBean getViewSurvey(String surveyId);

	public boolean getSurveyorRegistration(List<SurveyorInfoBean> surveyorRegistrationList);

	boolean getLoginSurvey(String surveyorId, String surveyPassword);

	public boolean getcheckSurvey(String surveyId);
}
