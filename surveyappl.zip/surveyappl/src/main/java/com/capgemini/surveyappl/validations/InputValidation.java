package com.capgemini.surveyappl.validations;

/**
 * This interface is used to provide implementation for inputValidation
 * implementation class.
 * 
 * @author ELCOT
 *
 */
public interface InputValidation {

	boolean choiceCheckValidation(String extractPerson);

	boolean passwordValidation(String password);

	boolean userIdValidation(String userid);

	boolean choiceCheckValidateOne(String extractPerson);

}
