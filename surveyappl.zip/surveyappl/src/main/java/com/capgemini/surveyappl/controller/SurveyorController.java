package com.capgemini.surveyappl.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;
import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.dao.RespondentDAOImplement;
import com.capgemini.surveyappl.exception.SurveyIdNotFoundException;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.SurveyorInfoBean;
import com.capgemini.surveyappl.dao.SurveyorDAOImplement;
import com.capgemini.surveyappl.exception.InvalidNoSurveyFoundException;
import com.capgemini.surveyappl.exception.InvalidSurveyorMisMatchException;
import com.capgemini.surveyappl.factory.FactoryClass;
import com.capgemini.surveyappl.service.SurveyorService;
import com.capgemini.surveyappl.service.SurveyorServiceImplement;

/**
 * This class is used to perform all operations of surveyor side.
 * 
 * @author ELCOT
 *
 */
public class SurveyorController {

	static final Logger logg = Logger.getLogger(SurveyorController.class);

	Scanner scann = new Scanner(System.in);

	Boolean flag;

	SurveyorService surveyorService = new SurveyorServiceImplement();

	int count = 0;

	/**
	 * This method is used to make the surveyor login part
	 * 
	 * @return true or false
	 */
	public boolean surveyorControllerLogin() {

		Properties file = new Properties();

		try {
			file.load(new FileInputStream("LoginCredentials.properties"));
		} catch (IOException e) {
			e.getMessage();
		}

		String surveyorId = file.getProperty("surveyorId");
		String surveyPassword = file.getProperty("surveyorPassword");

		try {
			boolean login = surveyorService.getLogin(surveyorId, surveyPassword);
			if (login) {
				logg.info("login Successful\n");
				FactoryClass.getSurveyorControllerInstance().getSurveyorCreateDetails();

			}
		} catch (InvalidSurveyorMisMatchException e) {
			logg.error(e.exceptionMessage());
		}
		return false;

	}

	/**
	 * This method is used to choose the options of below mentioned options
	 * 
	 */
	private void getSurveyorCreateDetails() {

		boolean survey = true;

		do {

			logg.info("**************Press the enter required following options****************\n");
			logg.info("1.Add Survey");
			logg.info("2.Update Survey");
			logg.info("3.Delete Survey");
			logg.info("4.View Survey");
			logg.info("5.ViewAll Survey");
			logg.info("6.Review of distributed survey responses");
			logg.info("7.exit\n");

			logg.info("Enter the Option..[1-7]");

			String extractPersonOne = scann.nextLine();
			while (!surveyorService.choiceCheckValidateOne(extractPersonOne)) {
				logg.info("Enter the valid Option..[1-7]");
				extractPersonOne = scann.nextLine();
			}

			int surveyorCRUD = Integer.parseInt(extractPersonOne);

			switch (surveyorCRUD) {
			case 1:
				logg.info("..........Addd survey Details........\n");
				FactoryClass.getSurveyorControllerInstance().insertSurvey();
				break;
			case 2:
				logg.info("......Update the Survey Detailsss.....\n");
				FactoryClass.getSurveyorControllerInstance().updateSurveyQuestionaries();
				break;
			case 3:
				logg.info("......Delete the Survey Details........\n");
				FactoryClass.getSurveyorControllerInstance().getDeleteSurvey();
				break;
			case 4:
				logg.info("......View Survey Details.....\n");
				FactoryClass.getSurveyorControllerInstance().getViewSurvey();
				break;
			case 5:
				logg.info("......View All  Survey Details.....\n");
				FactoryClass.getSurveyorControllerInstance().totalSurvey();
				break;
			case 6:
				logg.info("......Responses of distributed survey in the list.......\n");
				FactoryClass.getSurveyorControllerInstance().getReviewSurvey();
				break;
			case 7:
				survey = false;
				break;
			default:
				// it does not take any action
			}
		} while (survey);
	}

	/**
	 * This method is used to add the survey part
	 */
	public void insertSurvey() {

		CreateSurveyDetailsBean createsurveybean = FactoryClass.getCreateSurveyDetails();

		logg.info("Create your survey information here........ ");

		logg.info(" ");
		logg.info("Enter Survey Id.[Numbers only allowed of length [1-5]],[no spaces b/w words]");

		String surveyId = scann.nextLine();
		while (!surveyorService.idValidation(surveyId)) {
			logg.info("Enter valid Surveyid.[Numbers only allowed of length [1-5]],[no spaces b/w words]");
			surveyId = scann.nextLine();
		}

		boolean check = surveyorService.checkSurvey(surveyId);

		if (check) {
			logg.info("the survey id is already present..you can't create survey again using this survey id\n");
		} else {
			logg.info("2.Enter Name...[Lower and upper case alphabets only allowed]");

			String surveyName = scann.nextLine();
			while (!surveyorService.nameValidation(surveyName)) {
				logg.info("Enter valid Survey Name..[Lower and upper case alphabets only allowed]");
				surveyName = scann.nextLine();
			}
			logg.info("3. Enter Description...[Lower and upper case alphabets only allowed]");

			String surveyDescription = scann.nextLine();
			while (!surveyorService.surveyDescriptionValidation(surveyDescription)) {
				logg.info("Enter valid  Description..[Lower and upper case alphabets only allowed]");
				surveyDescription = scann.nextLine();
			}

			LocalDate startDate = null;
			boolean newStartDate = true;
			while (newStartDate) {
				try {
					logg.info("4.Enter Start Date...[Today or future date only allowed [YYYY-MM-DD format]]");

					String surveyStartDate = scann.nextLine();
					while (!surveyorService.startDateValidation(surveyStartDate)) {
						logg.info("Enter valid start date....[YYYY-MM-DD Format]");
						surveyStartDate = scann.nextLine();
					}
					startDate = LocalDate.parse(surveyStartDate);

					while (startDate.isBefore(LocalDate.now())) {
						logg.info("Enter the today or future date only allowed[YYYY-MM-DD Format ]");

						surveyStartDate = scann.nextLine();
						while (!surveyorService.startDateValidation(surveyStartDate)) {
							logg.info("Enter valid start date.[YYYY-MM-DD Format]");
							surveyStartDate = scann.nextLine();
						}
						startDate = LocalDate.parse(surveyStartDate);
					}
					startDate = LocalDate.parse(surveyStartDate);
					newStartDate = false;
				} catch (DateTimeException e) {
					logg.info("It is not valid");
					newStartDate = true;
				}
			}

			LocalDate endDate = null;
			boolean date = true;
			while (date) {
				logg.info("5. Enter End Date.[ after the start date only allowed [YYYY-MM-DD format]]");

				String surveyEndDate = scann.nextLine();
				while (!surveyorService.endDateValidation(surveyEndDate)) {
					logg.info("Enter Valid End date.[YYYY-MM-DD format]");
					surveyEndDate = scann.nextLine();
				}
				try {
					endDate = LocalDate.parse(surveyEndDate);
					while (!endDate.isAfter(startDate)) {
						logg.info("Enter the valid date after the start date[YYYY-MM-DD Format]");

						surveyEndDate = scann.nextLine();
						while (!surveyorService.endDateValidation(surveyEndDate)) {
							logg.info("Enter valid End date..[YYYY-MM-DD Format]");
							surveyEndDate = scann.nextLine();
						}
						endDate = LocalDate.parse(surveyEndDate);
					}
					endDate = LocalDate.parse(surveyEndDate);
					date = false;

				} catch (DateTimeException e) {
					logg.info("It is not Valid");
					date = true;
				}
			}

			logg.info("  ");
			logg.info("Create question for this survey");
			logg.info(" ");
			logg.info("1.Enter 1st Question...[Lower and upper case alphabets only allowed]");

			String questionOne = scann.nextLine();
			while (!surveyorService.questionValidation(questionOne)) {
				logg.info("Enter valid question[Lower and upper case alphabets only allowed]");
				questionOne = scann.nextLine();
			}
			logg.info("Enter the 1st option[Lower and upper case alphabets only allowed]");

			String questionOneOptionOne = scann.nextLine();
			while (!surveyorService.optionValidation(questionOneOptionOne)) {
				logg.info("Enter the Valid Option..[Lower and upper case alphabets only allowed]");
				questionOneOptionOne = scann.nextLine();
			}
			logg.info("Enter the 2nd option..[Lower and upper case alphabets only allowed]");

			String questionOneOptionTwo = scann.nextLine();
			while (!surveyorService.optionValidation(questionOneOptionTwo)) {
				logg.info("enter valid Option..[Lower and upper case alphabets only allowed]");
				questionOneOptionTwo = scann.nextLine();
			}
			logg.info("Enter the 3rd option..[Lower and upper case alphabets only allowed]");

			String questionOneOptionThree = scann.nextLine();
			while (!surveyorService.optionValidation(questionOneOptionThree)) {
				logg.info("Enter the Valid option..[Lower and upper case alphabets only allowed]");
				questionOneOptionThree = scann.nextLine();
			}
			logg.info("Enter the 4rd option..[Lower and upper case alphabets only allowed]");

			String questionOneOptionFour = scann.nextLine();
			while (!surveyorService.optionValidation(questionOneOptionFour)) {
				logg.info("Enter Valid option...[Lower and upper case alphabets only allowed]");
				questionOneOptionFour = scann.nextLine();
			}
			logg.info("************");
			logg.info("Enter the 2nd question...[Lower and upper case alphabets only allowed]");

			String questionTwo = scann.nextLine();
			while (!surveyorService.questionValidation(questionTwo)) {
				logg.info("enter valid Question..[Lower and upper case alphabets only allowed]");
				questionTwo = scann.nextLine();
			}
			logg.info("Enter the 1st option..[Lower and upper case alphabets only allowed]");

			String questionTwoOptionOne = scann.nextLine();
			while (!surveyorService.optionValidation(questionTwoOptionOne)) {
				logg.info("Enter valid option..[Lower and upper case alphabets only allowed]");
				questionTwoOptionOne = scann.nextLine();
			}
			logg.info("Enter the 2nd option..[Lower and upper case alphabets only allowed]");

			String questionTwoOptionTwo = scann.nextLine();
			while (!surveyorService.optionValidation(questionTwoOptionTwo)) {
				logg.info("Enter valid option..[Lower and upper case alphabets only allowed]");
				questionTwoOptionTwo = scann.nextLine();
			}
			logg.info("Enter the 3rd option..[Lower and upper case alphabets only allowed]");

			String questionTwoOptionThree = scann.nextLine();
			while (!surveyorService.optionValidation(questionTwoOptionThree)) {
				logg.info("enter the Valid option..[Lower and upper case alphabets only allowed]");
				questionTwoOptionThree = scann.nextLine();
			}
			logg.info("Enter the 4rd option..[Lower and upper case alphabets only allowed]");

			String questionTwoOptionFour = scann.nextLine();
			while (!surveyorService.optionValidation(questionTwoOptionFour)) {
				logg.info("Enter the valid Option..[Lower and upper case alphabets only allowed]");
				questionTwoOptionFour = scann.nextLine();
			}

			logg.info(
					"Enter respondent Name to share your Survey..[ [a-zA-Z0-9] characters of length [5-10] only allowed],[no spaces b/w words]");

			String name = scann.nextLine();
			while (!surveyorService.userNameValidation(name)) {
				logg.info(
						"Enter valid Name to share your survey..[ [a-zA-Z0-9] characters of length [5-10] only allowed],[ no spaces b/w words ]");
				name = scann.nextLine();
			}

			createsurveybean.setid(surveyId);
			createsurveybean.setname(surveyName);
			createsurveybean.setdescription(surveyDescription);
			createsurveybean.setStartDate(startDate);
			createsurveybean.setEndDate(endDate);
			createsurveybean.setquestionHasOneOption(questionOne);
			createsurveybean.setquestionOneOptionOne(questionOneOptionOne);
			createsurveybean.setquestionOneOptionTwo(questionOneOptionTwo);
			createsurveybean.setquestionOneOptionThree(questionOneOptionThree);
			createsurveybean.setquestionOneOptionFour(questionOneOptionFour);
			createsurveybean.setquestionHasMultipleOption(questionTwo);
			createsurveybean.setquestionTwoOptionOne(questionTwoOptionOne);
			createsurveybean.setquestionTwoOptionTwo(questionTwoOptionTwo);
			createsurveybean.setquestionTwoOptionThree(questionTwoOptionThree);
			createsurveybean.setquestionTwoOptionFour(questionTwoOptionFour);
			createsurveybean.setAccessor(name);

			ArrayList<CreateSurveyDetailsBean> surveylist = new ArrayList<>();
			surveylist.add(createsurveybean);

			boolean surveyadd = surveyorService.getSurveyorDaoAdd(surveylist);

			if (surveyadd)
				logg.info(" survey creation is Successful\n");
			else
				logg.info(" survey creation is not Successful\n");
		}
	}

	/**
	 * This method is used to edit survey part
	 */
	public void updateSurveyQuestionaries() {

		logg.info("the surveys are:\n");

		for (CreateSurveyDetailsBean survey : SurveyorDAOImplement.surveyorOne) {
			logg.info("*survey id:" + survey.getid() + " , " + "survey name :" + survey.getname());
		}

		logg.info("\nplease enter the survey id to update.[ Numbers only allowed]");

		String surveyId = scann.nextLine();
		while (!surveyorService.idValidation(surveyId)) {
			logg.info("Enter the valid surveyId.[ Numbers only allowed]");
			surveyId = scann.nextLine();
		}
		try {
			boolean updateSurvey = surveyorService.getUpdateSurvey(surveyId);

			if (updateSurvey) {
				logg.info("You cannot Make the Survey Edition Part because the survey is distributed already......\n");
			} else {
				logg.info("Your Survey is not distributed,you can make the updation for this Survey Id..........\n");

				logg.info("Do you want edit Survey Details or its QUestions...?");

				boolean update = true;
				do {

					logg.info("1.Edit Survey..");
					logg.info("2.Edit Survey Questions and option");
					logg.info("3.exit..\n");

					logg.info(" Enter the Option[1-3]");

					String choice = scann.nextLine();
					while (!surveyorService.choiceCheckValidate(choice)) {
						logg.info(" Enter the valid Option[1-3]");
						choice = scann.nextLine();
					}

					int surveyorCRUD = Integer.parseInt(choice);
					for (CreateSurveyDetailsBean cb : SurveyorDAOImplement.surveyorOne) {
						if (cb.getid().contentEquals(surveyId)) {
							count++;
							switch (surveyorCRUD) {
							case 1:
								logg.info("..........edit Questions........");

								logg.info(" ");
								logg.info("1.Enter new Survey Name..[Lower and upper case alphabets only allowed]");

								String surveyName = scann.nextLine();
								while (!surveyorService.nameValidation(surveyName)) {
									logg.info("Enter valid Survey Name.[Lower and upper case alphabets only allowed]");
									surveyName = scann.nextLine();
								}
								cb.setname(surveyName);

								logg.info(" ");
								logg.info(
										"2.Enter new Survey description.[Lower and upper case alphabets only allowed]");

								String surveyDescription = scann.nextLine();
								while (!surveyorService.surveyDescriptionValidation(surveyDescription)) {
									logg.info("Enter valid Description[Lower and upper case alphabets only allowed]");
									surveyDescription = scann.nextLine();
								}
								cb.setdescription(surveyDescription);

								logg.info(" ");
								LocalDate startDate = null;
								boolean date = true;
								while (date) {
									logg.info(
											"3.Enter the new start date.[Today or future date only allowed [YYYY-MM-DD format]]");

									String surveyStartDate = scann.nextLine();
									while (!surveyorService.startDateValidation(surveyStartDate)) {
										logg.info("Enter  valid startDate.[YYYY-MM-DD format]");
										surveyStartDate = scann.nextLine();
									}
									try {
										startDate = LocalDate.parse(surveyStartDate);

										while (startDate.isBefore(LocalDate.now())) {
											logg.info("Enter the today or future date[YYYY-MM-DD Format]");
											surveyStartDate = scann.nextLine();
											while (!surveyorService.startDateValidation(surveyStartDate)) {
												logg.info("Enter the valid startDate.[YYYY-MM-DD] Format");
												surveyStartDate = scann.nextLine();
											}
											startDate = LocalDate.parse(surveyStartDate);
										}
										startDate = LocalDate.parse(surveyStartDate);
										date = false;
									} catch (DateTimeException e) {
										logg.info("It is not valid");
										date = true;

									}
								}
								cb.setStartDate(startDate);

								logg.info(" ");
								LocalDate endDate = null;
								boolean end = true;
								while (end) {
									logg.info("4.Enter the end date.......[after starting date [YYYY-MM-DD format]]");

									String surveyendDate = scann.nextLine();
									while (!surveyorService.endDateValidation(surveyendDate)) {
										logg.info(" Enter valid End date.. [YYYY-MM-DD format]");
										surveyendDate = scann.nextLine();
									}

									try {
										endDate = LocalDate.parse(surveyendDate);
										while (!endDate.isAfter(startDate)) {
											logg.info(
													"please Enter the valid date after the starting date[YYYY-MM-DD format]");
											surveyendDate = scann.nextLine();
											while (!surveyorService.endDateValidation(surveyendDate)) {

												logg.info("Enter the valid End date.");
												surveyendDate = scann.nextLine();
											}

											endDate = LocalDate.parse(surveyendDate);
										}
										endDate = LocalDate.parse(surveyendDate);
										end = false;
									} catch (DateTimeException e) {
										logg.info("its not Valid");
										end = true;
									}
								}
								cb.setEndDate(endDate);
								logg.info("Survey updated successfully");
								logg.info(" ");
								break;
							case 2:

								logg.info("......Update the Survey Detailsss.....");
								logg.info("1.Enter new question[Lower and upper case alphabets only allowed]");

								String questionOne = scann.nextLine();
								while (!surveyorService.questionValidation(questionOne)) {
									logg.info("Enter valid new Question[Lower and upper case alphabets only allowed]");
									questionOne = scann.nextLine();
								}
								cb.setquestionHasOneOption(questionOne);

								logg.info("1.Enter new option...[Lower and upper case alphabets only allowed]");

								String questionOneOptionOne = scann.nextLine();
								while (!surveyorService.optionValidation(questionOneOptionOne)) {
									logg.info("Enter the valid option.[Lower and upper case alphabets only allowed]");
									questionOneOptionOne = scann.nextLine();
								}
								cb.setquestionOneOptionOne(questionOneOptionOne);

								logg.info("2.Enter new option.[Lower and upper case alphabets only allowed]");

								String questionOneOptionTwo = scann.nextLine();
								while (!surveyorService.optionValidation(questionOneOptionTwo)) {
									logg.info("Enter the valid option.[Lower and upper case alphabet only allowed]");
									questionOneOptionTwo = scann.nextLine();
								}
								cb.setquestionOneOptionTwo(questionOneOptionTwo);

								logg.info("3.Enter new option..[Lower and upper case alphabets only allowed]");

								String questionOneOptionThree = scann.nextLine();
								while (!surveyorService.optionValidation(questionOneOptionThree)) {
									logg.info("Enter  valid option.[Lower and upper case alphabets only allowed]");
									questionOneOptionThree = scann.nextLine();
								}
								cb.setquestionOneOptionThree(questionOneOptionThree);

								logg.info("4.Enter new option.[Lower and upper case alphabets only allowed]");

								String questionOneOptionFour = scann.nextLine();
								while (!surveyorService.optionValidation(questionOneOptionFour)) {
									logg.info(" Enter Valid option.[Lower and upper case alphabets only allowed]");
									questionOneOptionFour = scann.nextLine();
								}
								cb.setquestionOneOptionFour(questionOneOptionFour);

								logg.info("*********************");
								logg.info("2.Enter the new Question.[Lower and upper case alphabets only allowed]");

								String questionTwo = scann.nextLine();
								while (!surveyorService.questionValidation(questionTwo)) {
									logg.info(" Enter valid Question.[Lower and upper case alphabets only allowed]");
									questionTwo = scann.nextLine();
								}
								cb.setquestionHasMultipleOption(questionTwo);

								logg.info("1.Enter new option.[Lower and upper case alphabets only allowed]");

								String questionTwoOptionOne = scann.nextLine();
								while (!surveyorService.optionValidation(questionTwoOptionOne)) {
									logg.info(" Enter the Valid option[Lower and upper case alphabets only allowed]");
									questionTwoOptionOne = scann.nextLine();
								}
								cb.setquestionTwoOptionOne(questionTwoOptionOne);

								logg.info("2.Enter new option.[Lower and upper case alphabets only allowed]");

								String questionTwoOptionTwo = scann.nextLine();
								while (!surveyorService.optionValidation(questionTwoOptionTwo)) {
									logg.info("Enter valid option.[Lower and upper case alphabets only allowed]");
									questionTwoOptionTwo = scann.nextLine();
								}
								cb.setquestionTwoOptionTwo(questionTwoOptionTwo);

								logg.info("3.Enter new option.[Lower and upper case alphabets only allowed]");

								String questionTwoOptionThree = scann.nextLine();
								while (!surveyorService.optionValidation(questionTwoOptionThree)) {
									logg.info("Enter the Valid option.[Lower and upper case alphabets only allowed]");
									questionTwoOptionThree = scann.nextLine();
								}
								cb.setquestionTwoOptionThree(questionTwoOptionThree);

								logg.info("4.Enter new option.[Lower and upper case alphabets only allowed]");

								String questionTwoOptionFour = scann.nextLine();
								while (!surveyorService.optionValidation(questionTwoOptionFour)) {
									logg.info("Enter valid option.[Lower and upper case alphabets only allowed]");
									questionTwoOptionFour = scann.nextLine();
								}
								cb.setquestionTwoOptionFour(questionTwoOptionFour);

								logg.info(
										" Enter new  Respondent Name to share the  survey.[[a-zA-Z0-9] characters of length [5-10] only allowed ],[no spaces b/w words]");

								String name = scann.nextLine();
								while (!surveyorService.userNameValidation(name)) {
									logg.info(
											"Enter the valid name to share your survey.[[a-zA-Z0-9] characters of length [5-10] only allowed ],[no spaces b/w words]");
									name = scann.nextLine();
								}

								cb.setAccessor(name);

								logg.info("Survey Updated Successfully.....");
								logg.info(" ");
								break;

							case 3:
								update = false;
								break;

							default:
								// No process taken here
							}
						}
					}
					if (count == 0)
						throw new SurveyIdNotFoundException();
				} while (update);
			}

		} catch (

		SurveyIdNotFoundException e) {
			logg.error(e.exceptionMessage());
		}
	}

	/**
	 * This is method is used to delete survey in the list
	 */
	public void getDeleteSurvey() {

		logg.info("the surveys are:\n");

		for (CreateSurveyDetailsBean survey : SurveyorDAOImplement.surveyorOne) {
			logg.info("*survey id:" + survey.getid() + " , " + "survey name :" + survey.getname());
		}

		logg.info("\nEnter survey id to delete.[ Numbers only allowed]");

		String surveyId = scann.nextLine();
		while (!surveyorService.idValidation(surveyId)) {
			logg.info("Enter valid Surveyid.[Numbers only allowed]");
			surveyId = scann.nextLine();
		}
		try {
			boolean deleteSurvey = surveyorService.deleteSurvey(surveyId);
			if (deleteSurvey)
				logg.info("Survey deleted..");
			logg.info(" ");
		} catch (SurveyIdNotFoundException e) {
			logg.error(e.exceptionMessage());
		} catch (ConcurrentModificationException e) {
			logg.error(e.getMessage());
		}

	}

	/**
	 * this method is used to view particular survey details
	 */
	public void getViewSurvey() {

		logg.info("the surveys are:\n");

		for (CreateSurveyDetailsBean survey : SurveyorDAOImplement.surveyorOne) {
			logg.info("*survey id:" + survey.getid() + " , " + "survey name :" + survey.getname());
		}

		logg.info("\nEnter the survey id to display.[Numbers only allowed]");

		String surveyid = scann.nextLine();
		while (!surveyorService.idValidation(surveyid)) {
			logg.info("Enter valid Surveyid.[Numbers only allowed]");
			surveyid = scann.nextLine();
		}
		try {
			CreateSurveyDetailsBean b = surveyorService.viewSurvey(surveyid);
			logg.info(b);
		} catch (SurveyIdNotFoundException e) {
			logg.error(e.exceptionMessage());
		}

	}

	/**
	 * This method is used to view all responses and pending details
	 */
	public void getReviewSurvey() {

		for (CreateRespondentDetailsBean respondentBean : RespondentDAOImplement.respondentOne) {

			logg.info("surveyId is " + respondentBean.getquestionId() + "\n");
			logg.info("1." + respondentBean.getquestionOneAnswerOne());
			logg.info("2." + Arrays.toString(respondentBean.getfinalResult()) + "\n");

			logg.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
		}

	}

	/**
	 * This method is used to view all survey in the list
	 */
	public void totalSurvey() {

		boolean view = true;

		logg.info("Enter the option you want.... ?\n");
		do {
			logg.info("1. View all basic survey details");
			logg.info("2. View all full details of survey");
			logg.info("3.exit\n");

			logg.info("Enter the Option..[1-3]");
			String choice = scann.nextLine();
			while (!surveyorService.choiceCheckValidate(choice)) {
				logg.info("Enter the valid Option..[1-3]");
				choice = scann.nextLine();
			}
			int option = Integer.parseInt(choice);
			try {
				switch (option) {
				case 1:
					for (CreateSurveyDetailsBean survey : SurveyorDAOImplement.surveyorOne) {
						count++;
						logg.info("\nYour surveys informations  are:\n");

						logg.info("Surveyid          :" + " " + survey.getid());
						logg.info("SurveyName        :" + " " + survey.getname());
						logg.info("Survey Description:" + " " + survey.getdescription());
						logg.info("Survey StartDate  :" + " " + survey.getStartDate());
						logg.info("survey EndDate    :" + " " + survey.getEndDate());

						logg.info("********************************\n");
					}
					if (count == 0) {
						throw new InvalidNoSurveyFoundException();
					}
					break;

				case 2:

					logg.info("\nAll details of Survey are....\n");

					for (CreateSurveyDetailsBean survey : SurveyorDAOImplement.surveyorOne) {
						count++;
						if (survey != null) {

							logg.info(survey);
							logg.info("********************************\n");
						}
					}
					if (count == 0) {
						throw new InvalidNoSurveyFoundException();
					}
					break;

				case 3:

					view = false;
					break;
				default:
					// No process taken here

				}
			} catch (InvalidNoSurveyFoundException e) {
				logg.error(e.exceptionMessage());
			}

		} while (view);

	}

	/**
	 * This method is used to make registration of surveyor
	 */
	public void surveyRegistration() {

		SurveyorInfoBean surveyorbean = FactoryClass.getSurveyorBeanInstance();
		logg.info(" ");

		logg.info("Enter the  UserId.[[a-zA-Z0-9] characters only allowed of length [5-10]],[No spaces b/w words]");

		String id = scann.nextLine();
		while (!surveyorService.userNameValidation(id)) {
			logg.info(
					"Enter valid UserId.[[a-zA-Z0-9] characters only allowed of length [5-10]],[No spaces b/w words]");
			id = scann.nextLine();
		}
		logg.info("Enter your First Name.[[a-zA-Z] characters only allowed],[No spaces b/w words] ");

		String firstName = scann.nextLine();
		while (!surveyorService.firstLastNameValidation(firstName)) {
			logg.info("Enter valid First name.[[a-zA-Z]characters only allowed ],[No spaces b/w words] ");
			firstName = scann.nextLine();
		}

		logg.info("Enter your last Name.[[a-zA-Z]characters only allowed ],[No spaces b/w words] ");

		String lastName = scann.nextLine();
		while (!surveyorService.firstLastNameValidation(lastName)) {
			logg.info("Enter valid  Last name.[[a-zA-Z]characters only allowed ],[No spaces b/w words] ");
			lastName = scann.nextLine();
		}

		logg.info("Enter password.[[a-zA-Z0-9@$]characters only allowed ],[No spaces b/w words] ");

		String password = scann.nextLine();
		while (!surveyorService.passwordValidation(password)) {
			logg.info("Enter valid Password.[[a-zA-Z0-9@$]characters only allowed ],[No spaces b/w words] ");
			password = scann.nextLine();
		}

		logg.info("Enter your contactNumber.[ Must contains ten digits begins with number[6-9]]");

		String contactNo = scann.nextLine();
		while (!surveyorService.contactNumberValidation(contactNo)) {
			logg.info("Enter valid contactNumber.[ Must contains ten digits begins with number[6-9]]");
			contactNo = scann.nextLine();
		}
		surveyorbean.setuserId(id);
		surveyorbean.setfirstName(firstName);
		surveyorbean.setlastName(lastName);
		surveyorbean.setcontactNumber(contactNo);
		surveyorbean.setpassword(password);

		ArrayList<SurveyorInfoBean> surveyorregistrationList = new ArrayList<>();

		surveyorregistrationList.add(surveyorbean);

		boolean surveyorRegistration = surveyorService.getSurveyorRegistration(surveyorregistrationList);

		if (surveyorRegistration) {
			logg.info(" Registration Successfull\n");
		} else {
			logg.info(" Registration is not successfull\n");
		}
	}
}
