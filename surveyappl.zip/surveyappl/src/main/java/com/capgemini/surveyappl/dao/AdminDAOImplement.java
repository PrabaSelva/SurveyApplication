package com.capgemini.surveyappl.dao;

import java.util.List;
import com.capgemini.surveyappl.bean.AdminInfoBean;
import com.capgemini.surveyappl.exception.InvalidAdminMisMatchException;
import com.capgemini.surveyappl.repository.AdminRepository;

/**
 * This is adminDao class for performing CRUD operations of admin side.
 * 
 * @author ELCOT
 *
 */
public class AdminDAOImplement implements AdminDAO {

	public static List<AdminInfoBean> admin = new AdminRepository().adminInfoBean();

	int count = 0;

	public AdminDAOImplement() {

	}

	/**
	 * This method is used to call the admin login
	 * 
	 * @return true or false
	 * @param adminId,adminPassword
	 */
	@Override
	public boolean getAdminLogin(String adminId, String adminPassword) {
		for (AdminInfoBean AdminBeans : admin) {
			if (adminId.equals(AdminBeans.getadminUserName()) && adminPassword.equals(AdminBeans.getadminPassword())) {
				count++;
				return true;
			}
		}
		if (count == 0)
			throw new InvalidAdminMisMatchException();
		return false;
	}
}
