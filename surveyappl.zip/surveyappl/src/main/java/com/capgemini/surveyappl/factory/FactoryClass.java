package com.capgemini.surveyappl.factory;

import com.capgemini.surveyappl.service.SurveyorServiceImplement;
import com.capgemini.surveyappl.bean.AdminInfoBean;
import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.RespondentInfoBean;
import com.capgemini.surveyappl.bean.SurveyorInfoBean;
import com.capgemini.surveyappl.controller.AdminController;
import com.capgemini.surveyappl.controller.RespondentController;
import com.capgemini.surveyappl.controller.SurveyorController;
import com.capgemini.surveyappl.dao.SurveyorDAOImplement;
import com.capgemini.surveyappl.service.AdminService;
import com.capgemini.surveyappl.service.AdminServiceImplement;
import com.capgemini.surveyappl.service.ControllerService;
import com.capgemini.surveyappl.service.ControllerServiceImplement;
import com.capgemini.surveyappl.service.RespondentService;
import com.capgemini.surveyappl.service.RespondentServiceImplement;
import com.capgemini.surveyappl.dao.RespondentDAO;
import com.capgemini.surveyappl.dao.SurveyorDAO;
import com.capgemini.surveyappl.service.SurveyorService;
import com.capgemini.surveyappl.validations.AdminValidation;
import com.capgemini.surveyappl.validations.AdminValidationImplement;
import com.capgemini.surveyappl.validations.InputValidation;
import com.capgemini.surveyappl.validations.InputValidationImplement;
import com.capgemini.surveyappl.validations.RespondentValidation;
import com.capgemini.surveyappl.validations.RespondentValidationImplement;
import com.capgemini.surveyappl.validations.SurveyorValidation;
import com.capgemini.surveyappl.validations.SurveyorValidationImplement;
import com.capgemini.surveyappl.dao.*;

/**
 * This class is used to create object and return to its calling method..
 * 
 * @author ELCOT
 *
 */
public class FactoryClass {

	private FactoryClass() {

	}

	/**
	 * This method is used to get object of surveyor service class
	 * 
	 * @return surveyorService
	 */
	public static SurveyorService getSurveyorServiceInstance() {
		return new SurveyorServiceImplement();

	}

	/**
	 * This method is used to get object of SurveyorController class
	 * 
	 * @return surveyControl
	 */
	public static SurveyorController getSurveyorControllerInstance() {
		return new SurveyorController();

	}

	/**
	 * This method is used to get object of CreateSurveyBean class
	 * 
	 * @return createSurveybean
	 */
	public static CreateSurveyDetailsBean getCreateSurveyorBean() {
		return new CreateSurveyDetailsBean();

	}

	/**
	 * This method is used to get object of surveyor service class
	 * 
	 * @return surveyorinfoBean
	 */
	public static SurveyorInfoBean getSurveyorBeanInstance() {
		return new SurveyorInfoBean();

	}

	/**
	 * this method is used to get object of surveyor valid class
	 * 
	 * @return surveyValid
	 */
	public static SurveyorValidation getSurveyorValidation() {
		return new SurveyorValidationImplement();

	}

	/**
	 * This method is used to get the object of CreateSurveyDetailsBean class
	 * 
	 * @return createSurvey
	 */
	public static CreateSurveyDetailsBean getCreateSurveyDetails() {
		return new CreateSurveyDetailsBean();

	}

	/**
	 * This method is used to get the object of ControllerService class
	 * 
	 * @return createserviceObject
	 */
	public static ControllerService getcontrollerServiceInstance() {
		return new ControllerServiceImplement();
	}

	/**
	 * This method is used to get the object of RespondentInfoBean class
	 * 
	 * @return respondentBean
	 */
	public static RespondentInfoBean getRespondentBeanInstance() {
		return new RespondentInfoBean();

	}

	/**
	 * This method is used to get the object of surveyordao class
	 * 
	 * @return surveydao
	 */
	public static SurveyorDAO getSurveyorDAO() {
		return new SurveyorDAOImplement();

	}

	/**
	 * This method is used to get the object of respondentController class
	 * 
	 * @return respondentcontrollerObject
	 */
	public static RespondentController getRespondentServiceInstance() {
		return new RespondentController();
	}

	/**
	 * This method is used to get the object of CreateRespondentDetailsBean class
	 * 
	 * @return createrespondent
	 */
	public static CreateRespondentDetailsBean getRespondentDetailsBean() {
		return new CreateRespondentDetailsBean();

	}

	/**
	 * This method is used to get the object of AdminController class
	 * 
	 * @return admincontroller object
	 */
	public static AdminController getAdminControllerInstance() {
		return new AdminController();
	}

	/**
	 * This method is used to get the object of AdminInfoBean class
	 * 
	 * @return admininfoBean object
	 */
	public static AdminInfoBean getAdminBeanInstance() {
		return new AdminInfoBean();
	}

	/**
	 * This method is used to get the object of SurveyorValidationImpl class
	 * 
	 * @return surveyorValidation object
	 */
	public static SurveyorValidation getSurveyorValidationInstance() {
		return new SurveyorValidationImplement();
	}

	/**
	 * This method is used to get the object of RespondentValidationImpl class
	 * 
	 * @return respondentValidation class object
	 */
	public static RespondentValidation getRespondentValidation() {
		return new RespondentValidationImplement();
	}

	/**
	 * This method is used to get the object of input ValidationImpl class
	 * 
	 * @return object of input Validation
	 */
	public static InputValidation getInputValidation() {
		return new InputValidationImplement();
	}

	/**
	 * This method is used to get the object AdminValidationImpl class
	 * 
	 * @return admin validation object
	 */
	public static AdminValidation getAdminValidationInstance() {
		return new AdminValidationImplement();
	}

	/**
	 * This method is used to get the object of adminService class
	 * 
	 * @return adminService object
	 */
	public static AdminService getAdminSeviceInstance() {
		return new AdminServiceImplement();
	}

	/**
	 * This method is used to get the object of RespondentService class
	 * 
	 * @return respondentService
	 */
	public static RespondentService getRespondentServInstance() {
		return new RespondentServiceImplement();
	}

	/**
	 * This method is used to get the object of RespondetDAO class
	 * 
	 * @return respondentDao object
	 */
	public static RespondentDAO getRespondentDAOInstance() {
		return new RespondentDAOImplement();

	}

	/**
	 * This method is used to get the object of SurveyorDao class
	 * 
	 * @return surveyorDao Object
	 */
	public static SurveyorDAO getSurveyorDaoInstance() {
		return new SurveyorDAOImplement();
	}

}
