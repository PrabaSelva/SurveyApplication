package com.capgemini.surveyappl.bean;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * This survey bean class for getting and setting the values
 * 
 * @author ELCOT
 *
 */
public class CreateSurveyDetailsBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String accessor;

	private String id;

	private String name;

	private String description;

	private LocalDate startDate;

	private LocalDate endDate;

	private String questionHasOneOption;

	private String questionOneOptionOne;

	private String questionOneOptionTwo;

	private String questionOneOptionThree;

	private String questionOneOptionFour;

	private String questionHasMultipleOption;

	private String questionTwoOptionOne;

	private String questionTwoOptionTwo;

	private String questionTwoOptionThree;

	private String questionTwoOptionFour;

	public CreateSurveyDetailsBean() {

	}

	public String getAccessor() {
		return accessor;
	}

	public void setAccessor(String accessor) {
		this.accessor = accessor;
	}

	public String getid() {
		return id;
	}

	public void setid(String idOne) {
		this.id = idOne;
	}

	public String getname() {
		return name;
	}

	public void setname(String nameOne) {
		name = nameOne;
	}

	public String getdescription() {
		return description;
	}

	public void setdescription(String descriptionOne) {
		description = descriptionOne;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getquestionOneOptionOne() {
		return questionOneOptionOne;
	}

	public void setquestionOneOptionOne(String optionOne) {
		questionOneOptionOne = optionOne;
	}

	public String getquestionOneOptionTwo() {
		return questionOneOptionTwo;
	}

	public void setquestionOneOptionTwo(String optionTwo) {
		questionOneOptionTwo = optionTwo;
	}

	public String getquestionOneOptionThree() {
		return questionOneOptionThree;
	}

	public void setquestionOneOptionThree(String optionThree) {
		questionOneOptionThree = optionThree;
	}

	public String getquestionOneOptionFour() {
		return questionOneOptionFour;
	}

	public void setquestionOneOptionFour(String optionFour) {
		questionOneOptionFour = optionFour;
	}

	public String getquestionTwoOptionOne() {
		return questionTwoOptionOne;
	}

	public void setquestionTwoOptionOne(String optionOne) {
		questionTwoOptionOne = optionOne;
	}

	public String getquestionTwoOptionTwo() {
		return questionTwoOptionTwo;
	}

	public void setquestionTwoOptionTwo(String optionTwo) {
		questionTwoOptionTwo = optionTwo;
	}

	public String getquestionTwoOptionThree() {
		return questionTwoOptionThree;
	}

	public void setquestionTwoOptionThree(String optionThree) {
		questionTwoOptionThree = optionThree;
	}

	public String getquestionTwoOptionFour() {
		return questionTwoOptionFour;
	}

	public void setquestionTwoOptionFour(String optionFour) {
		questionTwoOptionFour = optionFour;
	}

	public String getquestionHasOneOption() {
		return questionHasOneOption;
	}

	public void setquestionHasOneOption(String questionsHasOneOptionOne) {
		questionHasOneOption = questionsHasOneOptionOne;
	}

	public String getquestionHasMultipleOption() {
		return questionHasMultipleOption;
	}

	public void setquestionHasMultipleOption(String questionsHasMultipleOptionOne) {
		questionHasMultipleOption = questionsHasMultipleOptionOne;
	}

	/**
	 * to string() override here
	 */
	public String toString() {
		return "Surveyid=" + id + ", Name=" + name + ", Description=" + description + ", startDate=" + startDate
				+ ", endDate=" + endDate + "" + "\n" + "\n 1." + questionHasOneOption + "\n a." + questionOneOptionOne
				+ "\n b." + questionOneOptionTwo + "\n c." + questionOneOptionThree + "\n d." + questionOneOptionFour
				+ "\n " + "\n 2." + questionHasMultipleOption + "\n a." + questionTwoOptionOne + "\n b."
				+ questionTwoOptionTwo + "\n c." + questionTwoOptionThree + "\n d." + questionTwoOptionFour + "\n";
	}

}
