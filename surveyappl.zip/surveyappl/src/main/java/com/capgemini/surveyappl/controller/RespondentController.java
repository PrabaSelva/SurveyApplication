package com.capgemini.surveyappl.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

import org.apache.log4j.Logger;
import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.RespondentInfoBean;
import com.capgemini.surveyappl.dao.RespondentDAOImplement;
import com.capgemini.surveyappl.dao.SurveyorDAOImplement;
import com.capgemini.surveyappl.exception.InvalidNotAuthenticateException;
import com.capgemini.surveyappl.exception.InvalidRespondentMisMatchException;
import com.capgemini.surveyappl.exception.SurveyIdNotFoundException;
import com.capgemini.surveyappl.factory.FactoryClass;
import com.capgemini.surveyappl.service.RespondentService;
import com.capgemini.surveyappl.service.RespondentServiceImplement;

/**
 * This class is used to perform all operations of respondent side..
 * 
 * @author ELCOT
 *
 */
public class RespondentController {

	RespondentService respondentService = new RespondentServiceImplement();

	static final Logger logg = Logger.getLogger(RespondentController.class);

	Scanner scann = new Scanner(System.in);

	int count = 0;

	/**
	 * This is respondent login part
	 */
	public void respControllerLoginCredentials() {

		logg.info(" ");
		logg.info(
				"Enter your respondent Id.[[a-zA-Z0-9] characters only allowed of length [5-10]],[No spaces b/w words]");
		String id = scann.nextLine();
		while (!respondentService.userNameValidation(id)) {
			logg.info(
					"Enter valid respondent id..[[a-zA-Z0-9] characters only allowed of length[5-10]],[No spaces b/w words]\n");
			id = scann.nextLine();
		}

		logg.info(" ");
		logg.info("Enter your respondent Password..[[a-zA-Z0-9@$] characters only allowed],[No spaces b/w words]");
		String password = scann.nextLine();
		while (!respondentService.passwordValidation(password)) {
			logg.info(
					" Enter valid respondent password..[ [a-zA-Z0-9@$]characters only allowed], [No spaces b/w words]\n");
			password = scann.nextLine();
		}

		try {
			boolean respondentlogin = respondentService.getRespondentLogin(id, password);
			if (respondentlogin) {

				logg.info(" ");
				logg.info("login successful\n");
				logg.info("The surveys are:\n");

				for (CreateSurveyDetailsBean survey : SurveyorDAOImplement.surveyorOne) {
					logg.info("*survey id:" + survey.getid() + " , " + "survey name :" + survey.getname());
				}

				logg.info("\nEnter the surveyid for making the responses[ex:numbers only allowed]");

				String surveyId = scann.nextLine();
				while (!respondentService.idValidation(surveyId)) {
					logg.info("Enter valid  surveyid for giving Responses.[ex:numbers only allowed]\n");
					surveyId = scann.nextLine();
				}
				try {
					for (CreateSurveyDetailsBean respbean : SurveyorDAOImplement.surveyorOne) {
						if (respbean.getid().contentEquals(surveyId)) {
							count++;
							if (respbean.getAccessor().contentEquals(id)) {
								FactoryClass.getRespondentServiceInstance().getCreateResponses(surveyId);
							} else {
								throw new InvalidNotAuthenticateException();
							}
						}
					}
					if (count == 0)
						throw new SurveyIdNotFoundException();
				} catch (InvalidNotAuthenticateException e) {
					logg.info(e.exceptionMessage());
				} catch (NullPointerException e) {
					e.getMessage();
				}
			}
		} catch (InvalidRespondentMisMatchException e) {
			logg.error(e.exceptionMessage());
		} catch (SurveyIdNotFoundException e) {
			logg.error(e.exceptionMessage());
		}

	}

	/**
	 * This method is used to choose option in the respondent side
	 * 
	 * @param userid1
	 */
	private void getCreateResponses(String surveyId) {

		boolean flag = true;
		do {

			logg.info(" ");
			logg.info("Select your choice..\n");
			logg.info("1.Add responses of the survey..");
			logg.info("2.View all Responses of the survey ..");
			logg.info("3.exit\n");

			logg.info("Enter the Choice...[1-3]");
			String responses = scann.nextLine();

			while (!respondentService.choiceRespondentValidation(responses)) {
				logg.info("Enter the valid choice...[1-3]");
				responses = scann.nextLine();
			}
			int responsesOne = Integer.parseInt(responses);

			switch (responsesOne) {
			case 1:

				FactoryClass.getRespondentServiceInstance().getResponses(surveyId);
				break;
			case 2:

				FactoryClass.getRespondentServiceInstance().viewResponses(surveyId);
				break;
			case 3:

				flag = false;
				break;
			default:

				// No process taken care
			}
		} while (flag);
	}

	/**
	 * This method is used to give to responses to the survey questionnaires
	 * 
	 * @param userid1
	 */
	private void getResponses(String surveyId) {

		CreateRespondentDetailsBean respondentDetails = FactoryClass.getRespondentDetailsBean();

		RespondentInfoBean respondentBean = FactoryClass.getRespondentBeanInstance();

		try {
			CreateSurveyDetailsBean respbean = respondentService.getResponse(surveyId);

			logg.info(" ");
			logg.info(" The following survey Questions are...\n");
			logg.info("1." + respbean.getquestionHasOneOption() + "\n");
			logg.info("1." + respbean.getquestionOneOptionOne());
			logg.info("2." + respbean.getquestionOneOptionTwo());
			logg.info("3." + respbean.getquestionOneOptionThree());
			logg.info("4." + respbean.getquestionOneOptionFour() + " \n");

			logg.info("please choose Single Option.[1-4]");

			String answerOne = scann.nextLine();
			while (!respondentService.answerValidation(answerOne)) {
				logg.info("Enter the Valid Option.[1-4]");
				answerOne = scann.nextLine();
			}
			int answerTwo = Integer.parseInt(answerOne);

			if (answerTwo == 1)
				respondentDetails.setquestionOneAnswerOne(respbean.getquestionOneOptionOne());
			else if (answerTwo == 2)
				respondentDetails.setquestionOneAnswerOne(respbean.getquestionOneOptionTwo());
			else if (answerTwo == 3)
				respondentDetails.setquestionOneAnswerOne(respbean.getquestionOneOptionThree());
			else
				respondentDetails.setquestionOneAnswerOne(respbean.getquestionOneOptionFour());

			logg.info(" ");

			logg.info("2." + respbean.getquestionHasMultipleOption());
			logg.info("  ");
			logg.info("1." + respbean.getquestionTwoOptionOne());
			logg.info("2." + respbean.getquestionTwoOptionTwo());
			logg.info("3." + respbean.getquestionTwoOptionThree());
			logg.info("4." + respbean.getquestionTwoOptionFour());
			logg.info(" ");

			HashSet<String> arrayList = new HashSet<>();

			logg.info("how many times  you will choose the option(multi choice answer).[1-4]");

			String choiceTimes = scann.nextLine();
			while (!respondentService.answerValidation(choiceTimes)) {
				logg.info("Enter valid choose.[1-4]");
				choiceTimes = scann.nextLine();
			}

			int options = Integer.parseInt(choiceTimes);

			for (int i = 1; i <= options; i++) {
				logg.info("\n" + i + ".Choose your option.[1-4] ");

				String answer = scann.nextLine();
				while (!respondentService.answerValidation(answer)) {
					logg.info("\n" + i + "Enter valid Option.[1-4]");
					answer = scann.nextLine();
				}

				int answers = Integer.parseInt(answer);

				switch (answers) {
				case 1:
					logg.info("1." + respbean.getquestionTwoOptionOne());
					logg.info(" ");
					arrayList.add(respbean.getquestionTwoOptionOne());
					break;
				case 2:
					logg.info("2." + respbean.getquestionTwoOptionTwo());
					logg.info(" ");
					arrayList.add(respbean.getquestionTwoOptionTwo());
					break;
				case 3:
					logg.info("3." + respbean.getquestionTwoOptionThree());
					logg.info(" ");
					arrayList.add(respbean.getquestionTwoOptionThree());
					break;
				case 4:
					logg.info("4." + respbean.getquestionTwoOptionFour());
					logg.info(" ");
					arrayList.add(respbean.getquestionTwoOptionFour());
					break;
				default:
					// No process taken here
				}
			}
			String[] resultArray = new String[arrayList.size()];
			int i = 0;

			for (String string : arrayList) {
				resultArray[i++] = string;
			}

			respondentDetails.setfinalResult(resultArray);
			respondentDetails.setrespondentId(respondentBean.getrespondentId());
			respondentDetails.setquestionId(surveyId);
			ArrayList<CreateRespondentDetailsBean> results = new ArrayList<>();
			results.add(respondentDetails);

			boolean flag = respondentService.getResponsesAdd(results);

			if (flag) {
				logg.info("Responses added Successfully\n");
				logg.info("**************************************");

			} else {
				logg.info("responses is not added Successfully");
				logg.info("**************************************");
			}
		} catch (SurveyIdNotFoundException e) {
			logg.error(e.exceptionMessage());
		}
	}

	/**
	 * This method is used to view the survey Responses from respondent
	 * 
	 * @exception SurveyIdNotFoundException
	 */

	public boolean viewResponses(String surveyId) {

		logg.info("********************************");

		try {

			for (CreateSurveyDetailsBean respondentBean : SurveyorDAOImplement.surveyorOne) {
				for (CreateRespondentDetailsBean respondentDetails : RespondentDAOImplement.respondentOne) {
					if (respondentBean.getid().contentEquals(surveyId)
							&& respondentDetails.getquestionId().contentEquals(surveyId)) {
						count++;

						logg.info(" ");
						logg.info("1." + respondentBean.getquestionHasOneOption());
						logg.info(" ");
						logg.info(respondentBean.getquestionOneOptionOne());
						logg.info(respondentBean.getquestionOneOptionTwo());
						logg.info(respondentBean.getquestionOneOptionThree());
						logg.info(respondentBean.getquestionOneOptionFour());
						logg.info(" ");
						logg.info("Answer:" + respondentDetails.getquestionOneAnswerOne());

						logg.info(" ");
						logg.info("2." + respondentBean.getquestionHasMultipleOption());
						logg.info(" ");
						logg.info(respondentBean.getquestionTwoOptionOne());
						logg.info(respondentBean.getquestionTwoOptionTwo());
						logg.info(respondentBean.getquestionTwoOptionThree());
						logg.info(respondentBean.getquestionTwoOptionFour());
						logg.info(" ");
						logg.info("Answer:" + Arrays.toString(respondentDetails.getfinalResult()));
						logg.info(" ");
						logg.info("******************************");
					}
				}
			}
			if (count == 0)
				throw new SurveyIdNotFoundException();
		} catch (SurveyIdNotFoundException e) {
			logg.error(e.exceptionMessage());
		}
		return true;
	}

	/**
	 * This method is used to make registration in respondent part
	 */
	public void respondentRegistration() {

		RespondentInfoBean respondentbean = FactoryClass.getRespondentBeanInstance();

		logg.info(" ");

		logg.info(
				"Enter the Respondent userid.[[a-zA-Z0-9] characters only allowed of length [5-10]],[No spaces b/w words]");

		String id = scann.nextLine();
		while (!respondentService.userNameValidation(id)) {
			logg.info(
					"enter valid userid.[[a-zA-Z0-9] characters only allowed of length [5-10]],[No spaces b/w words]");
			id = scann.nextLine();
		}

		logg.info("Enter your First Name.[[a-zA-Z]characters only allowed],[no spaces b/w words]");

		String firstName = scann.nextLine();
		while (!respondentService.nameValidation(firstName)) {
			logg.info("enter valid First name.[[a-zA-Z]characters only allowed],[no spaces b/w words]");
			firstName = scann.nextLine();
		}

		logg.info("Enter your last Name.[[a-zA-Z]characters only allowed],[no spaces b/w words]");

		String lastName = scann.nextLine();
		while (!respondentService.nameValidation(lastName)) {
			logg.info("enter valid  Last name.[[a-zA-Z]characters only allowed],[no spaces b/w words]");
			lastName = scann.nextLine();
		}
		logg.info("Enter your password.[[a-zA-Z0-9$@]characters only allowed],[no spaces b/w words]");

		String password = scann.nextLine();
		while (!respondentService.passwordValidation(password)) {
			logg.info("enter valid Password.[[a-zA-Z0-9$@]characters only allowed],[no spaces b/w words]");
			password = scann.nextLine();
		}

		logg.info("Enter your contactNumber..[ Must contains ten digits begins with number[6-9]]");

		String contactNo = scann.nextLine();
		while (!respondentService.contactNumberValidation(contactNo)) {
			logg.info("enter valid contactNumber.[ Must contains ten digits begins with number[6-9]].");
			contactNo = scann.nextLine();
		}
		respondentbean.setrespondentId(id);
		respondentbean.setrespondentFirstName(firstName);
		respondentbean.setrespondentLastName(lastName);
		respondentbean.setrespondentContact(contactNo);
		respondentbean.setrespondentPassword(password);

		ArrayList<RespondentInfoBean> registrationList = new ArrayList<>();
		registrationList.add(respondentbean);

		boolean flag = respondentService.getRespondentRegistration(registrationList);
		if (flag) {
			logg.info(" ");
			logg.info("Respondent Registration is Successfull..\n");
		} else {
			logg.info("respondent Registration is not Successful...\n");
		}
	}
}
