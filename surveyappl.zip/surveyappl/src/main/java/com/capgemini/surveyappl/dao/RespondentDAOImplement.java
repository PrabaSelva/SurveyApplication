package com.capgemini.surveyappl.dao;

import java.util.ArrayList;
import java.util.List;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.exception.InvalidRespondentMisMatchException;
import com.capgemini.surveyappl.exception.SurveyIdNotFoundException;
import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.RespondentInfoBean;
import com.capgemini.surveyappl.repository.RespondentRepository;

/**
 * This class is used to perform CRUD operations of respondent side
 * 
 * @author ELCOT
 *
 */
public class RespondentDAOImplement implements RespondentDAO {

	public static List<RespondentInfoBean> respondent = new RespondentRepository().respondentBean();

	public static List<CreateRespondentDetailsBean> respondentOne = new RespondentRepository().respondentDetails();

	int count = 0;

	/**
	 * This method is used to view the responses of respondent
	 * 
	 * @param surveyid
	 * @return respbean
	 * @throws SurveyIdNotFoundException
	 */
	@Override
	public CreateSurveyDetailsBean getResponseOfRespondent(String surveyId) {
		for (CreateSurveyDetailsBean bean : SurveyorDAOImplement.surveyorOne) {
			if (bean.getid().contentEquals(surveyId)) {
				count++;
				return bean;
			}
		}
		if (count == 0) {
			throw new SurveyIdNotFoundException();
		}
		return null;
	}

	/**
	 * This method is used to add responses in the list
	 * 
	 * @return true or false
	 * @param sl
	 */
	@Override
	public boolean getResponseAdd(ArrayList<CreateRespondentDetailsBean> list) {
		return respondentOne.addAll(list);

	}

	/**
	 * This method is used to make the registration of respondent
	 * 
	 * @return true or false
	 * @param reglist
	 */
	@Override
	public boolean getRespondentRegistration(ArrayList<RespondentInfoBean> registrationList) {
		return respondent.addAll(registrationList);

	}

	/**
	 * This method is used to make the respondent login
	 * 
	 * @return true or false
	 * @param id,password
	 */
	@Override
	public boolean getRespondentLogin(String id, String password) {
		for (RespondentInfoBean respondentbean : RespondentDAOImplement.respondent) {
			if (id.equals(respondentbean.getrespondentId())
					&& password.equals(respondentbean.getrespondentPassword())) {
				count++;
				return true;
			}
		}
		if (count == 0)
			throw new InvalidRespondentMisMatchException();
		return false;
	}
}