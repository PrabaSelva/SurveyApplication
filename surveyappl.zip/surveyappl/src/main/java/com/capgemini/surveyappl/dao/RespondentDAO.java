package com.capgemini.surveyappl.dao;

import java.util.ArrayList;

import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.RespondentInfoBean;

/**
 * This interface provides implementation to RespondentDAOImplementation class
 * 
 * @author ELCOT
 *
 */
public interface RespondentDAO {

	CreateSurveyDetailsBean getResponseOfRespondent(String surveyId);

	boolean getResponseAdd(ArrayList<CreateRespondentDetailsBean> list);

	boolean getRespondentRegistration(ArrayList<RespondentInfoBean> registrationList);

	boolean getRespondentLogin(String id, String password);

}
