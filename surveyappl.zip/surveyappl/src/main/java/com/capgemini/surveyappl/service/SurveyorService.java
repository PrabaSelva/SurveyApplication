package com.capgemini.surveyappl.service;

import java.util.ArrayList;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.SurveyorInfoBean;

/**
 * This is interface is used to implementation to SurveyorServiceImplementation
 * class..
 * 
 * @author ELCOT
 *
 */
public interface SurveyorService {

	boolean choiceCheckValidateOne(String extractPerson);

	boolean idValidation(String surveyId);

	boolean nameValidation(String surveyName);

	boolean startDateValidation(String surveyStartDate);

	boolean endDateValidation(String surveyEndDate);

	boolean optionValidation(String option);

	boolean getSurveyorDaoAdd(ArrayList<CreateSurveyDetailsBean> surveyList);

	boolean deleteSurvey(String surveyId);

	boolean choiceCheckValidate(String choice);

	CreateSurveyDetailsBean viewSurvey(String surveyId);

	boolean getUpdateSurvey(String surveyId);

	boolean userNameValidation(String id);

	boolean passwordValidation(String password);

	boolean contactNumberValidation(String contactNumber);

	boolean getSurveyorRegistration(ArrayList<SurveyorInfoBean> surveyorRegistrationList);

	boolean getLogin(String surveyorId, String surveyPassword);

	boolean surveyDescriptionValidation(String surveyDescription);

	boolean questionValidation(String question);

	boolean firstLastNameValidation(String firstLastName);

	boolean checkSurvey(String surveyId);

}
