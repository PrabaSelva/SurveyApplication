package com.capgemini.surveyappl.service;

import java.util.ArrayList;

import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.RespondentInfoBean;

/**
 * This is interface is used to implementation to
 * respondentServiceImplementation class..
 * 
 * @author ELCOT
 *
 */
public interface RespondentService {

	boolean userNameValidation(String respondentName);

	boolean passwordValidation(String password);

	boolean idValidation(String userId);

	boolean choiceRespondentValidation(String responses);

	CreateSurveyDetailsBean getResponse(String userId);

	boolean answerValidation(String answer);

	boolean getResponsesAdd(ArrayList<CreateRespondentDetailsBean> list);

	boolean nameValidation(String firstName);

	boolean contactNumberValidation(String contactNumber);

	boolean getRespondentRegistration(ArrayList<RespondentInfoBean> registrationList);

	boolean getRespondentLogin(String id, String password);

}
