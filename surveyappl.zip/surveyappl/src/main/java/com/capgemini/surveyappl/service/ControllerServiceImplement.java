package com.capgemini.surveyappl.service;

import com.capgemini.surveyappl.validations.InputValidation;
import com.capgemini.surveyappl.validations.InputValidationImplement;

/**
 * This class is used to perform validations for main controller properties
 * 
 * @author ELCOT
 *
 */
public class ControllerServiceImplement implements ControllerService {

	InputValidation inputValid = new InputValidationImplement();

	/**
	 * This method is used to check the choice
	 * 
	 * @return true or false
	 * @param extractPerson
	 */
	@Override 
	public boolean choiceCheckValidation(String extractPerson) {

		if (extractPerson != null) {
			return inputValid.choiceCheckValidation(extractPerson);
		}

		return false;
	}

}
