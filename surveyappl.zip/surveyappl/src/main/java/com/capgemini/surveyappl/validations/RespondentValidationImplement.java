
package com.capgemini.surveyappl.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is used tp perform all validations of respondent side.
 * 
 * @author ELCOT
 *
 */
public class RespondentValidationImplement implements RespondentValidation {

	Pattern pattn = null;
	Matcher mattn = null;

	/**
	 * This method is used to check answer validation
	 * 
	 * @return true or false
	 * @param answer
	 * 
	 */
	@Override
	public boolean answerValidation(String answer) {
		pattn = Pattern.compile("[1-4]");
		mattn = pattn.matcher(answer);
		return mattn.matches();
	}

	/**
	 * This method is used to check singlelineQuestion validation
	 * 
	 * @param singleline
	 * @return true or false
	 */
	@Override
	public boolean singleLineQuestionValidation(String singleline) {
		pattn = Pattern.compile("^[a-zA-Z] {1,200}$");
		mattn = pattn.matcher(singleline);
		return mattn.matches();
	}

	/**
	 * This method is used to check the multiple line question Validation
	 * 
	 * @param multipleline
	 * @return true or false
	 */
	@Override
	public boolean multipleLineQuestionValidation(String multipleline) {
		pattn = Pattern.compile("^[a-zA-Z] {1,4000}$");
		mattn = pattn.matcher(multipleline);
		return mattn.matches();
	}

	/**
	 * This method is used to check the choice in respondent
	 * 
	 * @param responses
	 * @return true or false
	 */
	@Override
	public boolean choiceRespondentValidation(String responses) {
		pattn = Pattern.compile("[1-3]");
		mattn = pattn.matcher(responses);
		return mattn.matches();
	}

	/**
	 * This method is used to check password validation
	 * 
	 * @return true or false
	 * @param password
	 *            as argument
	 */
	public boolean passwordValidation(String password) {
		pattn = Pattern.compile("[a-zA-Z0-9@$]+");
		mattn = pattn.matcher(password);
		return mattn.matches();

	}

	/**
	 * This method is used to check the id validation
	 * 
	 * @param surveyid
	 *            return true or false
	 */
	@Override
	public boolean idValidation(String surveyId) {
		pattn = Pattern.compile("\\d{1,5}");
		mattn = pattn.matcher(surveyId);
		return mattn.matches();
	}

	/**
	 * this method is used to check the userName validation
	 * 
	 * @param respondetName
	 * @return true or false
	 */
	public boolean userNameValidation(String respondentname) {
		pattn = Pattern.compile("^[a-zA-Z0-9]{5,10}+");
		mattn = pattn.matcher(respondentname);
		return mattn.matches();
	}

	/**
	 * This method is used to check the nameValidation
	 * 
	 * @param fname
	 * @return true or false
	 */
	@Override
	public boolean nameValidation(String name) {
		pattn = Pattern.compile("[a-zA-Z]+");
		mattn = pattn.matcher(name);
		return mattn.matches();
	}

	/**
	 * This method is used to check the contactNumber validation
	 * 
	 * @param contactNo
	 * @return true or false
	 */
	@Override
	public boolean contactNumberValidation(String contactNumber) {
		pattn = Pattern.compile("[6-9][0-9]{9}");
		mattn = pattn.matcher(contactNumber);
		return mattn.matches();
	}

}
