package com.capgemini.surveyappl.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.bean.SurveyorInfoBean;
import com.capgemini.surveyappl.factory.FactoryClass;

/**
 * This is Surveyor Repository class
 * 
 * @author ELCOT
 *
 */
public class SurveyorRepository {

	static List<SurveyorInfoBean> surveyor = new ArrayList<>();

	static List<CreateSurveyDetailsBean> surveyorOne = new ArrayList<>();

	/**
	 * This method is used to give dummy data for surveyor login
	 * 
	 * @return surveyor
	 */
	public List<SurveyorInfoBean> surveyorInfoBean() {

		List<SurveyorInfoBean> surveyorList = new ArrayList<>();

		SurveyorInfoBean surveyorBean = FactoryClass.getSurveyorBeanInstance();

		surveyorBean.setuserId("surveyor");
		surveyorBean.setpassword("12345678");

		surveyorList.add(surveyorBean);
		return surveyorList;

	}

	/**
	 * This method is used to give dummy data for surveyor survey details
	 * 
	 * @return surveyor1
	 */

	public List<CreateSurveyDetailsBean> createSurveyBean() {

		List<CreateSurveyDetailsBean> surveyorListOne = new ArrayList<>();

		ArrayList<CreateSurveyDetailsBean> surveyList = new ArrayList<>();

		CreateSurveyDetailsBean createsurveyBean = FactoryClass.getCreateSurveyorBean();
		createsurveyBean.setAccessor("respondent");
		createsurveyBean.setid("1");
		createsurveyBean.setdescription("This is favorite place in india..How its actually ..? ");
		createsurveyBean.setname(" survey about places ");
		createsurveyBean.setStartDate(LocalDate.of(1997, 03, 06));
		createsurveyBean.setEndDate(LocalDate.of(1998, 03, 07));
		createsurveyBean.setquestionHasOneOption("what is your favorite Place..?");
		createsurveyBean.setquestionHasMultipleOption("what are the things you like in the place..?");
		createsurveyBean.setquestionOneOptionOne("Ooty");
		createsurveyBean.setquestionOneOptionTwo("Mysoru");
		createsurveyBean.setquestionOneOptionThree("Agra ");
		createsurveyBean.setquestionOneOptionFour("Goa");
		createsurveyBean.setquestionTwoOptionOne("Gardens");
		createsurveyBean.setquestionTwoOptionTwo("Temples");
		createsurveyBean.setquestionTwoOptionThree("Museum");
		createsurveyBean.setquestionTwoOptionFour("Parks");

		surveyList.add(createsurveyBean);

		CreateSurveyDetailsBean createsurveyBeanOne = FactoryClass.getCreateSurveyorBean();
		createsurveyBeanOne.setAccessor("respond");
		createsurveyBeanOne.setid("2");
		createsurveyBeanOne.setdescription(
				"This is medical eqipments survey..We have to collect feedback from our customer side ");
		createsurveyBeanOne.setname("Medical equipment survey");
		createsurveyBeanOne.setStartDate(LocalDate.of(1997, 03, 06));
		createsurveyBeanOne.setEndDate(LocalDate.of(1998, 03, 06));
		createsurveyBeanOne.setquestionHasOneOption("How about your satisfication..?");
		createsurveyBeanOne.setquestionHasMultipleOption("which is the best Products in our company...");
		createsurveyBeanOne.setquestionOneOptionOne("Good");
		createsurveyBeanOne.setquestionOneOptionTwo("Bad");
		createsurveyBeanOne.setquestionOneOptionThree("Average");
		createsurveyBeanOne.setquestionOneOptionFour("Super");
		createsurveyBeanOne.setquestionTwoOptionOne("Sugar test Machine");
		createsurveyBeanOne.setquestionTwoOptionTwo("Ventilator");
		createsurveyBeanOne.setquestionTwoOptionThree("cholesterol Analyser");
		createsurveyBeanOne.setquestionTwoOptionFour("Nasal tubings");

		surveyList.add(createsurveyBeanOne);

		surveyorListOne.addAll(surveyList);

		return surveyorListOne;
	}
}
