package com.capgemini.surveyappl.exception;

import org.apache.log4j.Logger;

/**
 * This is invalid respondentMismatch exception
 * 
 * @author ELCOT
 *
 */
public class InvalidRespondentMisMatchException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	static final Logger logger = Logger.getLogger(InvalidRespondentMisMatchException.class);

	String message = "Respondent Login failed......\n";

	/**
	 * This returns exception message
	 * 
	 * @return message
	 */
	public String exceptionMessage() {
		return message;
	}
}
