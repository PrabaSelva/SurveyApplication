package com.capgemini.surveyappl.dao;

import java.util.ConcurrentModificationException;
import java.util.List;

import com.capgemini.surveyappl.exception.InvalidSurveyorMisMatchException;
import com.capgemini.surveyappl.exception.SurveyIdNotFoundException;
import com.capgemini.surveyappl.bean.CreateRespondentDetailsBean;
import com.capgemini.surveyappl.bean.CreateSurveyDetailsBean;
import com.capgemini.surveyappl.repository.SurveyorRepository;
import com.capgemini.surveyappl.bean.SurveyorInfoBean;

/**
 * This class is used to perform CRUD operation of Surveyor Side..
 * 
 * @author ELCOT
 *
 */
public class SurveyorDAOImplement implements SurveyorDAO {

	public static List<SurveyorInfoBean> surveyor = new SurveyorRepository().surveyorInfoBean();

	public static List<CreateSurveyDetailsBean> surveyorOne = new SurveyorRepository().createSurveyBean();

	int count = 0;

	/**
	 * This method is used to login surveyor
	 * 
	 * @return true or false
	 * @param surveyorId
	 * @param surveyPassword
	 */
	@Override
	public boolean getLoginSurvey(String surveyorId, String surveyPassword) {
		for (SurveyorInfoBean surveyorBeans : surveyor) {
			if (surveyorId.equals(surveyorBeans.getuserId()) && surveyPassword.equals(surveyorBeans.getpassword())) {
				count++;
				return true;
			}
		}
		if (count == 0)
			throw new InvalidSurveyorMisMatchException();
		return false;
	}

	/**
	 * This method is used to add survey in the list
	 * 
	 * @return true or false
	 * @param surveylist
	 */
	@Override
	public boolean getSurveyadd(List<CreateSurveyDetailsBean> surveyList) {
		return surveyorOne.addAll(surveyList);

	}

	/**
	 * This method is used to view Survey in the list
	 * 
	 * @return CreateSurveyBeanDetails
	 * @param surveyid
	 */
	public CreateSurveyDetailsBean getViewSurvey(String surveyId) {

		for (CreateSurveyDetailsBean createsurveyBean : surveyorOne) {
			if (createsurveyBean.getid().equals(surveyId)) {
				count++;
				return createsurveyBean;
			}
		}
		if (count == 0) {
			throw new SurveyIdNotFoundException();
		}
		return null;
	}

	/**
	 * This method is used to delete survey in the list
	 * 
	 * @return true or false
	 * @param surveyid
	 * @throws SurveyIdNotFoundException,ConcurrentModificationException
	 */
	@Override
	public boolean getDeleteSurvey(String surveyId) {
		try {
			for (CreateSurveyDetailsBean createSurveyBean : surveyorOne) {
				if (createSurveyBean.getid().equals(surveyId)) {
					count++;
					surveyorOne.remove(createSurveyBean);
					return true;
				}
			}
			if (count == 0)
				throw new SurveyIdNotFoundException();
		} catch (ConcurrentModificationException e) {
			throw new ConcurrentModificationException();
		}
		return false;
	}

	/**
	 * This method is used to update the survey in the list
	 * 
	 * @param surveyid
	 * @return true or false
	 */
	@Override
	public boolean getSurveyUpdate(String surveyId) {
		for (CreateSurveyDetailsBean createSurveyBean : surveyorOne) {
			if (createSurveyBean.getid().contentEquals(surveyId)) {
				count++;
				for (CreateRespondentDetailsBean rb : RespondentDAOImplement.respondentOne) {
					if (rb.getquestionId().contentEquals(surveyId)) {
						return true;
					}
				}
			}
		}
		if (count == 0) {
			throw new SurveyIdNotFoundException();
		}
		return false;
	}

	/**
	 * This method is used to make registration of surveyor
	 * 
	 * @param surveyreglist
	 * @return true or false
	 * 
	 */
	@Override
	public boolean getSurveyorRegistration(List<SurveyorInfoBean> surveyorRegistrationList) {
		return surveyor.addAll(surveyorRegistrationList);

	}

	/**
	 * This method is used to check the survey id is present in list or not
	 * 
	 * @return true or false
	 * @param surveyId
	 * 
	 */
	@Override
	public boolean getcheckSurvey(String surveyId) {
		for (CreateSurveyDetailsBean createsurveyBean : surveyorOne) {
			if (createsurveyBean.getid().equals(surveyId)) {
				count++;
				return true;
			}
		}
		return false;
	}

}