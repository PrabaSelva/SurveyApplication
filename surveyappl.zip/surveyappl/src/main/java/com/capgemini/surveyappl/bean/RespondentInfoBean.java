package com.capgemini.surveyappl.bean;

import java.io.Serializable;

/**
 * This is respondent registration bean class
 * 
 * @author ELCOT
 *
 */

public class RespondentInfoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String respondentId;

	private String respondentPassword;

	private String respondentFirstName;

	private String respondentLastName;

	private String respondentContact;

	public RespondentInfoBean() {

	}

	public String getrespondentId() {
		return respondentId;
	}

	public void setrespondentId(String respondentIdOne) {
		respondentId = respondentIdOne;
	}

	public String getrespondentPassword() {
		return respondentPassword;
	}

	public void setrespondentPassword(String respondentPasswordOne) {
		respondentPassword = respondentPasswordOne;
	}

	public String getrespondentFirstName() {
		return respondentFirstName;
	}

	public void setrespondentFirstName(String respondentFirstNameOne) {
		respondentFirstName = respondentFirstNameOne;
	}

	public String getrespondentLastName() {
		return respondentLastName;
	}

	public void setrespondentLastName(String respondentLastNameOne) {
		respondentLastName = respondentLastNameOne;
	}

	public String getrespondentContact() {
		return respondentContact;
	}

	public void setrespondentContact(String respondentContactOne) {
		respondentContact = respondentContactOne;
	}

}
