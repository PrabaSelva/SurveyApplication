package com.capgemini.surveyappl.bean;

import java.io.Serializable;

/**
 * This is survey registration bean class
 * 
 * @author ELCOT
 *
 */

public class SurveyorInfoBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userId;

	private String password;

	private String firstName;

	private String contactNumber;

	private String lastName;

	public SurveyorInfoBean() {

	}

	public String getuserId() {
		return userId;
	}

	public void setuserId(String userIdOne) {
		this.userId = userIdOne;
	}

	public String getpassword() {
		return password;
	}

	public void setpassword(String passwordOne) {
		this.password = passwordOne;
	}

	public String getfirstName() {
		return firstName;
	}

	public void setfirstName(String firstNameOne) {
		this.firstName = firstNameOne;
	}

	public String getcontactNumber() {
		return contactNumber;
	}

	public void setcontactNumber(String contactNumberOne) {
		this.contactNumber = contactNumberOne;
	}

	public String getlastName() {
		return lastName;
	}

	public void setlastName(String lastNameOne) {
		this.lastName = lastNameOne;
	}

	/**
	 * toString() is override
	 */
	public String toString() {
		return "SurveyorInfoBean [sEmail=" + userId + ", sPassword=" + password + "]";
	}

}
