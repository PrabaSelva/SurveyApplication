package com.capgemini.surveyappl.service;

import com.capgemini.surveyappl.dao.AdminDAO;
import com.capgemini.surveyappl.dao.AdminDAOImplement;
import com.capgemini.surveyappl.validations.AdminValidation;
import com.capgemini.surveyappl.validations.AdminValidationImplement;

/**
 * This class is used to perform validations and establishing connection
 * admindao side.
 * 
 * @author ELCOT
 *
 */
public class AdminServiceImplement implements AdminService {

	AdminValidation adminValid = new AdminValidationImplement();

	AdminDAO adminDao = new AdminDAOImplement();

	/**
	 * This method is used to check the choice in adminpart
	 * 
	 * @return true or false
	 * @param extractPerson
	 */
	@Override
	public boolean choiceCheckValidation(String extractPerson) {

		if (extractPerson != null) {
			return adminValid.choiceCheckValidation(extractPerson);
		}

		return false;
	}

	/**
	 * This method is used to check the admin login
	 * 
	 * @return true or false
	 * @param adminId,adminPassword
	 */
	@Override
	public boolean getAdminLogin(String adminId, String adminPassword) {

		if ((adminId != null) && (adminPassword != null)) {
			return adminDao.getAdminLogin(adminId, adminPassword);
		}
		return false;
	}

}
