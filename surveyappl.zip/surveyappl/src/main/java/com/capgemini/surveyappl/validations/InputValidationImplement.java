package com.capgemini.surveyappl.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This is validation class is used to perform all basic common validations of
 * each modulus side.
 * 
 * @author ELCOT
 *
 */
public class InputValidationImplement implements InputValidation {

	Pattern pattn = null;
	Matcher mattn = null;

	/**
	 * This method is used to check the choice
	 * 
	 * @return true or false
	 * @param extractperson
	 *            as argument
	 */
	public boolean choiceCheckValidation(String extractPerson) {
		pattn = Pattern.compile("[1-4]");
		mattn = pattn.matcher(extractPerson);
		return mattn.matches();
	}

	/**
	 * This method is used to check password validation
	 * 
	 * @return true or false
	 * @param password
	 *            as argument
	 */
	public boolean passwordValidation(String password) {
		pattn = Pattern.compile("[a-zA-Z0-9@$]+");
		mattn = pattn.matcher(password);
		return mattn.matches();

	}

	/**
	 * This method is used to check userid validation
	 * 
	 * @return true or false
	 * @param userid
	 *            as argument
	 */
	public boolean userIdValidation(String userid) {
		pattn = Pattern.compile("[a-zA-Z0-9@$]+");
		mattn = pattn.matcher(userid);
		return mattn.matches();
	}

	/**
	 * This method is used to check choice
	 * 
	 * @param extractPerson1
	 * @return true or false
	 */
	public boolean choiceCheckValidateOne(String extractPerson) {
		pattn = Pattern.compile("[1-7]");
		mattn = pattn.matcher(extractPerson);
		return mattn.matches();
	}

}